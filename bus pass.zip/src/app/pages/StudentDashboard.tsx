import { Navbar } from "../components/Navbar";
import { useState, useEffect } from "react";
import { useNavigate } from "react-router";
import {
  User,
  CreditCard,
  MessageSquare,
  Bus,
  Calendar,
  MapPin,
  Clock,
  CheckCircle,
  AlertCircle,
  Ticket,
  DollarSign,
  AlertTriangle,
} from "lucide-react";
import { authAPI, mockData } from "../utils/api";
import { motion } from "motion/react";

export function StudentDashboard() {
  const navigate = useNavigate();
  const [currentUser, setCurrentUser] = useState<any>(null);
  const [studentPass, setStudentPass] = useState<any>(null);
  const [studentComplaints, setStudentComplaints] = useState<any[]>([]);

  useEffect(() => {
    // Check if user is logged in
    const user = authAPI.getCurrentUser();
    if (!user || user.role !== 'student') {
      navigate('/login');
      return;
    }

    setCurrentUser(user);

    // Get student's pass
    const pass = mockData.passes.find(p => p.student_id === user.student_id);
    setStudentPass(pass);

    // Get student's complaints
    const complaints = mockData.complaints.filter(c => c.student_id === user.student_id);
    setStudentComplaints(complaints);
  }, [navigate]);

  if (!currentUser) {
    return null;
  }

  const getRouteName = (routeId: number) => {
    const route = mockData.routes.find(r => r.route_id === routeId);
    return route ? route.route_name : "Unknown";
  };

  const getStopName = (stopId: number) => {
    const stop = mockData.stops.find(s => s.stop_id === stopId);
    return stop ? stop.stop_name : "Unknown";
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString("en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
    });
  };

  const getDaysRemaining = (validTo: string) => {
    const today = new Date();
    const endDate = new Date(validTo);
    const diffTime = endDate.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
  };

  const getDaysUntilDue = (dueDate: string) => {
    const today = new Date();
    const due = new Date(dueDate);
    const diffTime = due.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
  };

  const isPastDue = (dueDate: string) => {
    const today = new Date();
    const due = new Date(dueDate);
    return today > due;
  };

  return (
    <div className="min-h-screen bg-slate-50">
      <Navbar />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Welcome Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <h1 className="text-3xl font-bold text-slate-900 mb-2">
            Welcome back, {currentUser.studentData?.name}! 👋
          </h1>
          <p className="text-slate-600">
            Here's your bus pass overview and activity
          </p>
        </motion.div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="bg-white rounded-2xl shadow-md p-6 border border-slate-200"
          >
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-gradient-to-br from-emerald-400 to-emerald-600 rounded-xl flex items-center justify-center shadow-lg">
                <User className="w-6 h-6 text-white" />
              </div>
              <div>
                <p className="text-sm text-slate-600">Student ID</p>
                <p className="text-xl font-bold text-slate-900">
                  {currentUser.student_id}
                </p>
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="bg-white rounded-2xl shadow-md p-6 border border-slate-200"
          >
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-gradient-to-br from-indigo-400 to-indigo-600 rounded-xl flex items-center justify-center shadow-lg">
                <CreditCard className="w-6 h-6 text-white" />
              </div>
              <div>
                <p className="text-sm text-slate-600">Pass Status</p>
                <p className="text-xl font-bold text-emerald-600">
                  {studentPass ? "Active" : "No Pass"}
                </p>
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="bg-white rounded-2xl shadow-md p-6 border border-slate-200"
          >
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-gradient-to-br from-amber-400 to-amber-600 rounded-xl flex items-center justify-center shadow-lg">
                <MessageSquare className="w-6 h-6 text-white" />
              </div>
              <div>
                <p className="text-sm text-slate-600">Complaints</p>
                <p className="text-xl font-bold text-slate-900">
                  {studentComplaints.length}
                </p>
              </div>
            </div>
          </motion.div>
        </div>

        {/* Fee Payment Reminder */}
        {studentPass && !studentPass.fee_paid && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.35 }}
            className={`mb-8 rounded-3xl shadow-lg p-6 border-2 ${
              isPastDue(studentPass.fee_due_date)
                ? "bg-gradient-to-r from-red-50 to-rose-50 border-red-300"
                : "bg-gradient-to-r from-amber-50 to-yellow-50 border-amber-300"
            }`}
          >
            <div className="flex items-start gap-4">
              <div
                className={`w-14 h-14 ${
                  isPastDue(studentPass.fee_due_date)
                    ? "bg-gradient-to-br from-red-500 to-red-600"
                    : "bg-gradient-to-br from-amber-500 to-amber-600"
                } rounded-2xl flex items-center justify-center shadow-lg`}
              >
                {isPastDue(studentPass.fee_due_date) ? (
                  <AlertTriangle className="w-7 h-7 text-white" />
                ) : (
                  <DollarSign className="w-7 h-7 text-white" />
                )}
              </div>
              <div className="flex-1">
                <h3
                  className={`text-xl font-bold mb-2 ${
                    isPastDue(studentPass.fee_due_date) ? "text-red-900" : "text-amber-900"
                  }`}
                >
                  {isPastDue(studentPass.fee_due_date) ? "⚠️ Payment Overdue!" : "💰 Fee Payment Reminder"}
                </h3>
                <p
                  className={`mb-4 ${
                    isPastDue(studentPass.fee_due_date) ? "text-red-800" : "text-amber-800"
                  }`}
                >
                  {isPastDue(studentPass.fee_due_date)
                    ? `Your bus pass fee payment is overdue by ${Math.abs(getDaysUntilDue(studentPass.fee_due_date))} days. Please make payment immediately to avoid service disruption.`
                    : `Your bus pass fee payment of ₹${studentPass.fee_amount} is due in ${getDaysUntilDue(studentPass.fee_due_date)} days (${formatDate(studentPass.fee_due_date)}).`}
                </p>
                <div className="flex flex-wrap gap-3">
                  <div
                    className={`px-4 py-2 ${
                      isPastDue(studentPass.fee_due_date) ? "bg-red-100" : "bg-amber-100"
                    } rounded-xl`}
                  >
                    <p className="text-sm text-slate-600 font-medium">Amount Due</p>
                    <p
                      className={`text-2xl font-bold ${
                        isPastDue(studentPass.fee_due_date) ? "text-red-900" : "text-amber-900"
                      }`}
                    >
                      ₹{studentPass.fee_amount}
                    </p>
                  </div>
                  <div
                    className={`px-4 py-2 ${
                      isPastDue(studentPass.fee_due_date) ? "bg-red-100" : "bg-amber-100"
                    } rounded-xl`}
                  >
                    <p className="text-sm text-slate-600 font-medium">Due Date</p>
                    <p
                      className={`text-lg font-bold ${
                        isPastDue(studentPass.fee_due_date) ? "text-red-900" : "text-amber-900"
                      }`}
                    >
                      {formatDate(studentPass.fee_due_date)}
                    </p>
                  </div>
                  <button
                    className={`px-6 py-2 ${
                      isPastDue(studentPass.fee_due_date)
                        ? "bg-gradient-to-r from-red-600 to-red-700 hover:from-red-700 hover:to-red-800"
                        : "bg-gradient-to-r from-amber-600 to-amber-700 hover:from-amber-700 hover:to-amber-800"
                    } text-white rounded-xl font-semibold transition-all shadow-md`}
                  >
                    Pay Now
                  </button>
                </div>
              </div>
            </div>
          </motion.div>
        )}

        {/* Book Day Ticket Banner */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.38 }}
          className="mb-8 bg-gradient-to-r from-indigo-600 to-purple-600 rounded-3xl shadow-xl p-6 text-white"
        >
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 bg-white/20 backdrop-blur-sm rounded-2xl flex items-center justify-center">
                <Ticket className="w-8 h-8 text-white" />
              </div>
              <div>
                <h3 className="text-2xl font-bold mb-1">Need a bus for just a few days?</h3>
                <p className="text-indigo-100">Book single or multiple day tickets instead of a full pass!</p>
              </div>
            </div>
            <button
              onClick={() => navigate('/book-day-ticket')}
              className="px-8 py-3 bg-white text-indigo-600 rounded-2xl font-bold hover:bg-indigo-50 transition-all shadow-lg whitespace-nowrap"
            >
              Book Day Ticket
            </button>
          </div>
        </motion.div>

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Column - Pass Details */}
          <div className="lg:col-span-2 space-y-6">
            {/* Active Bus Pass Card */}
            {studentPass ? (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.4 }}
                className="bg-gradient-to-br from-emerald-600 to-emerald-700 rounded-3xl shadow-2xl p-8 text-white"
              >
                <div className="flex justify-between items-start mb-6">
                  <div>
                    <p className="text-emerald-100 text-sm mb-1">Active Bus Pass</p>
                    <h2 className="text-2xl font-bold">Pass #{studentPass.pass_id}</h2>
                  </div>
                  <div className="bg-white/20 backdrop-blur-sm px-4 py-2 rounded-full">
                    <p className="text-sm font-semibold">Active</p>
                  </div>
                </div>

                <div className="space-y-4 mb-6">
                  <div className="flex items-center gap-3">
                    <Bus className="w-5 h-5 text-emerald-200" />
                    <div>
                      <p className="text-emerald-100 text-sm">Route</p>
                      <p className="font-semibold">{getRouteName(studentPass.route_id)}</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    <MapPin className="w-5 h-5 text-emerald-200" />
                    <div>
                      <p className="text-emerald-100 text-sm">Boarding Stop</p>
                      <p className="font-semibold">{getStopName(studentPass.stop_id)}</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    <Calendar className="w-5 h-5 text-emerald-200" />
                    <div>
                      <p className="text-emerald-100 text-sm">Validity Period</p>
                      <p className="font-semibold">
                        {formatDate(studentPass.valid_from)} - {formatDate(studentPass.valid_to)}
                      </p>
                    </div>
                  </div>
                </div>

                <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-4 border border-white/20">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-emerald-100 text-sm">Days Remaining</p>
                      <p className="text-2xl font-bold">{getDaysRemaining(studentPass.valid_to)}</p>
                    </div>
                    <Clock className="w-8 h-8 text-emerald-200" />
                  </div>
                </div>
              </motion.div>
            ) : (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.4 }}
                className="bg-white rounded-3xl shadow-md p-8 border border-slate-200 text-center"
              >
                <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <CreditCard className="w-8 h-8 text-slate-400" />
                </div>
                <h3 className="text-xl font-bold text-slate-900 mb-2">No Active Pass</h3>
                <p className="text-slate-600 mb-6">
                  You don't have an active bus pass yet. Apply for one to start using college bus services.
                </p>
                <button
                  onClick={() => navigate('/pass-registration')}
                  className="px-6 py-3 bg-gradient-to-r from-emerald-600 to-emerald-700 text-white rounded-2xl font-semibold hover:from-emerald-700 hover:to-emerald-800 transition-all shadow-lg"
                >
                  Apply for Pass
                </button>
              </motion.div>
            )}

            {/* Student Information */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5 }}
              className="bg-white rounded-3xl shadow-md p-6 border border-slate-200"
            >
              <h3 className="text-xl font-bold text-slate-900 mb-6">Personal Information</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <p className="text-sm text-slate-600 mb-1">Full Name</p>
                  <p className="font-semibold text-slate-900">{currentUser.studentData?.name}</p>
                </div>
                <div>
                  <p className="text-sm text-slate-600 mb-1">Email</p>
                  <p className="font-semibold text-slate-900">{currentUser.studentData?.email}</p>
                </div>
                <div>
                  <p className="text-sm text-slate-600 mb-1">Department</p>
                  <p className="font-semibold text-slate-900">{currentUser.studentData?.department}</p>
                </div>
                <div>
                  <p className="text-sm text-slate-600 mb-1">Year</p>
                  <p className="font-semibold text-slate-900">{currentUser.studentData?.year}</p>
                </div>
                <div>
                  <p className="text-sm text-slate-600 mb-1">Mobile</p>
                  <p className="font-semibold text-slate-900">{currentUser.studentData?.mobile}</p>
                </div>
                <div>
                  <p className="text-sm text-slate-600 mb-1">Student ID</p>
                  <p className="font-semibold text-slate-900">{currentUser.student_id}</p>
                </div>
              </div>
            </motion.div>
          </div>

          {/* Right Column - Quick Actions & Complaints */}
          <div className="space-y-6">
            {/* Quick Actions */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.6 }}
              className="bg-white rounded-3xl shadow-md p-6 border border-slate-200"
            >
              <h3 className="text-xl font-bold text-slate-900 mb-6">Quick Actions</h3>
              <div className="space-y-3">
                <button
                  onClick={() => navigate('/pass-registration')}
                  className="w-full flex items-center gap-3 px-4 py-3 bg-emerald-50 border border-emerald-200 text-emerald-700 rounded-2xl font-medium hover:bg-emerald-100 transition-all"
                >
                  <CreditCard className="w-5 h-5" />
                  Apply for New Pass
                </button>
                <button
                  onClick={() => navigate('/buses')}
                  className="w-full flex items-center gap-3 px-4 py-3 bg-indigo-50 border border-indigo-200 text-indigo-700 rounded-2xl font-medium hover:bg-indigo-100 transition-all"
                >
                  <Bus className="w-5 h-5" />
                  View Bus Routes
                </button>
                <button
                  onClick={() => navigate('/complaints')}
                  className="w-full flex items-center gap-3 px-4 py-3 bg-amber-50 border border-amber-200 text-amber-700 rounded-2xl font-medium hover:bg-amber-100 transition-all"
                >
                  <MessageSquare className="w-5 h-5" />
                  File a Complaint
                </button>
              </div>
            </motion.div>

            {/* Recent Complaints */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.7 }}
              className="bg-white rounded-3xl shadow-md p-6 border border-slate-200"
            >
              <h3 className="text-xl font-bold text-slate-900 mb-6">My Complaints</h3>
              {studentComplaints.length > 0 ? (
                <div className="space-y-4">
                  {studentComplaints.map((complaint) => (
                    <div
                      key={complaint.complaint_id}
                      className="p-4 bg-slate-50 rounded-2xl border border-slate-200"
                    >
                      <div className="flex items-start gap-3 mb-2">
                        <AlertCircle className="w-5 h-5 text-amber-600 mt-0.5" />
                        <div className="flex-1">
                          <p className="text-sm font-medium text-slate-900">
                            Complaint #{complaint.complaint_id}
                          </p>
                          <p className="text-sm text-slate-600 mt-1">
                            {complaint.description}
                          </p>
                          <p className="text-xs text-slate-500 mt-2">
                            {formatDate(complaint.date)}
                          </p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8">
                  <CheckCircle className="w-12 h-12 text-emerald-500 mx-auto mb-3" />
                  <p className="text-slate-600">No complaints filed</p>
                </div>
              )}
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  );
}