import { Navbar } from "../components/Navbar";
import { useState } from "react";
import { MessageSquare, User, Calendar, CheckCircle, AlertCircle } from "lucide-react";
import { mockData } from "../utils/api";

export function ComplaintPage() {
  const [formData, setFormData] = useState({
    student_id: "",
    description: "",
  });
  const [submitted, setSubmitted] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [showHistory, setShowHistory] = useState(false);

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    if (!formData.student_id) {
      newErrors.student_id = "Student selection is required";
    }
    if (!formData.description.trim()) {
      newErrors.description = "Complaint description is required";
    } else if (formData.description.trim().length < 10) {
      newErrors.description = "Description must be at least 10 characters";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!validateForm()) {
      return;
    }

    try {
      // Mock API call - Replace with actual API endpoint
      // const response = await complaintAPI.create(formData);
      
      const complaintData = {
        ...formData,
        complaint_id: Math.floor(Math.random() * 10000),
        date: new Date().toISOString().split("T")[0],
      };
      
      console.log("Complaint Data:", complaintData);
      
      // Simulate API success
      setSubmitted(true);
      
      // Reset form after 3 seconds
      setTimeout(() => {
        setFormData({ student_id: "", description: "" });
        setSubmitted(false);
      }, 3000);
    } catch (error) {
      console.error("Complaint Submission Error:", error);
      alert("Failed to submit complaint. Please try again.");
    }
  };

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    
    // Clear error when user starts typing
    if (errors[name]) {
      setErrors((prev) => ({ ...prev, [name]: "" }));
    }
  };

  const getStudentName = (id: number) => {
    const student = mockData.students.find((s) => s.student_id === id);
    return student ? student.name : "Unknown";
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString("en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
    });
  };

  if (submitted) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Navbar />
        <div className="flex items-center justify-center p-8 mt-20">
          <div className="bg-white rounded-xl shadow-lg p-12 max-w-md text-center">
            <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <CheckCircle className="w-12 h-12 text-green-600" />
            </div>
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Complaint Submitted!
            </h2>
            <p className="text-gray-600 mb-6">
              Your complaint has been registered and will be reviewed by the
              administration team.
            </p>
            <div className="bg-orange-50 rounded-lg p-4 mb-6">
              <p className="text-sm text-orange-900">
                <strong>Reference ID:</strong>{" "}
                {Math.floor(Math.random() * 10000)}
              </p>
            </div>
            <p className="text-sm text-gray-500">Redirecting to form...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50">
      <Navbar />

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Page Header */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-cyan-600 rounded-lg mb-4 shadow-md">
            <MessageSquare className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-3xl font-bold text-slate-900 mb-2">
            Submit Complaint
          </h1>
          <p className="text-slate-600">
            Report any issues or concerns regarding bus services
          </p>
        </div>

        {/* Complaint Form */}
        <div className="bg-white rounded-lg shadow-lg p-8 mb-8">
          <form onSubmit={handleSubmit}>
            {/* Student Selection */}
            <div className="mb-6">
              <label className="flex items-center gap-2 text-sm font-medium text-gray-700 mb-2">
                <User className="w-4 h-4" />
                Select Student *
              </label>
              <select
                name="student_id"
                value={formData.student_id}
                onChange={handleChange}
                className={`w-full px-4 py-3 border ${
                  errors.student_id ? "border-red-500" : "border-gray-300"
                } rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent`}
              >
                <option value="">Choose your name</option>
                {mockData.students.map((student) => (
                  <option key={student.student_id} value={student.student_id}>
                    {student.name} - {student.department}
                  </option>
                ))}
              </select>
              {errors.student_id && (
                <p className="text-red-500 text-sm mt-1">{errors.student_id}</p>
              )}
            </div>

            {/* Complaint Description */}
            <div className="mb-6">
              <label className="flex items-center gap-2 text-sm font-medium text-gray-700 mb-2">
                <MessageSquare className="w-4 h-4" />
                Complaint Description *
              </label>
              <textarea
                name="description"
                value={formData.description}
                onChange={handleChange}
                rows={6}
                placeholder="Describe your complaint in detail..."
                className={`w-full px-4 py-3 border ${
                  errors.description ? "border-red-500" : "border-gray-300"
                } rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none`}
              />
              {errors.description && (
                <p className="text-red-500 text-sm mt-1">
                  {errors.description}
                </p>
              )}
              <p className="text-sm text-gray-500 mt-1">
                Minimum 10 characters required
              </p>
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              className="w-full px-6 py-4 bg-cyan-600 text-white rounded-lg font-semibold hover:bg-cyan-700 transition-all text-lg shadow-md"
            >
              Submit Complaint
            </button>
          </form>

          <div className="mt-6 p-4 bg-cyan-50 rounded-lg border border-cyan-200 flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-cyan-600 flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-sm text-slate-900">
                <strong>Note:</strong> Your complaint will be reviewed by the
                administration team within 2-3 business days. You will be
                contacted for any follow-up.
              </p>
            </div>
          </div>
        </div>

        {/* Complaint History Toggle */}
        <div className="text-center mb-6">
          <button
            onClick={() => setShowHistory(!showHistory)}
            className="px-6 py-3 bg-white text-cyan-600 border-2 border-cyan-600 rounded-lg font-semibold hover:bg-cyan-50 transition-all shadow-md"
          >
            {showHistory ? "Hide" : "View"} Complaint History
          </button>
        </div>

        {/* Complaint History */}
        {showHistory && (
          <div className="bg-white rounded-lg shadow-lg overflow-hidden">
            <div className="px-6 py-4 bg-gray-50 border-b border-gray-200">
              <h3 className="text-lg font-semibold text-gray-900">
                Previous Complaints
              </h3>
            </div>

            {mockData.complaints.length === 0 ? (
              <div className="p-12 text-center">
                <MessageSquare className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-gray-900 mb-2">
                  No complaints found
                </h3>
                <p className="text-gray-600">
                  There are no complaints in the system
                </p>
              </div>
            ) : (
              <div className="divide-y divide-gray-200">
                {mockData.complaints.map((complaint) => (
                  <div key={complaint.complaint_id} className="p-6">
                    <div className="flex justify-between items-start mb-3">
                      <div>
                        <h4 className="font-semibold text-gray-900">
                          Complaint #{complaint.complaint_id}
                        </h4>
                        <p className="text-sm text-gray-600">
                          By: {getStudentName(complaint.student_id)}
                        </p>
                      </div>
                      <div className="flex items-center gap-2 text-sm text-gray-600">
                        <Calendar className="w-4 h-4" />
                        {formatDate(complaint.date)}
                      </div>
                    </div>
                    <p className="text-gray-700">{complaint.description}</p>
                    <div className="mt-3">
                      <span className="inline-flex items-center px-3 py-1 bg-yellow-100 text-yellow-700 rounded-full text-sm font-medium">
                        <Clock className="w-4 h-4 mr-1" />
                        Under Review
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

function Clock({ className }: { className?: string }) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
    >
      <circle cx="12" cy="12" r="10"></circle>
      <polyline points="12 6 12 12 16 14"></polyline>
    </svg>
  );
}