import { Navbar } from "../components/Navbar";
import { Link } from "react-router";
import { Bus, UserCircle, FileText, MessageCircle, ShieldCheck, TrendingUp, Users, CheckCircle, ArrowRight, Sparkles } from "lucide-react";
import { motion } from "motion/react";
import { AnimatedCampusScene } from "../components/AnimatedCampusScene";

export function HomePage() {
  const quickActions = [
    {
      icon: UserCircle,
      title: "Student Portal",
      description: "Login or register your account",
      link: "/login",
      gradient: "from-indigo-500 to-indigo-600",
      iconBg: "bg-indigo-50",
      iconColor: "text-indigo-600",
    },
    {
      icon: FileText,
      title: "Apply for Pass",
      description: "Get your digital bus pass",
      link: "/pass-registration",
      gradient: "from-emerald-500 to-emerald-600",
      iconBg: "bg-emerald-50",
      iconColor: "text-emerald-600",
    },
    {
      icon: MessageCircle,
      title: "Support",
      description: "Submit complaints & feedback",
      link: "/complaint",
      gradient: "from-amber-500 to-amber-600",
      iconBg: "bg-amber-50",
      iconColor: "text-amber-600",
    },
    {
      icon: ShieldCheck,
      title: "Admin Access",
      description: "Staff dashboard login",
      link: "/login",
      gradient: "from-slate-600 to-slate-700",
      iconBg: "bg-slate-50",
      iconColor: "text-slate-600",
    },
  ];

  const features = [
    {
      icon: CheckCircle,
      title: "Instant Approval",
      description: "Get your pass approved within 24 hours",
    },
    {
      icon: TrendingUp,
      title: "Real-time Tracking",
      description: "Track your application status live",
    },
    {
      icon: Users,
      title: "Multi-route Access",
      description: "Choose from 12+ campus routes",
    },
  ];

  const stats = [
    { value: "1,200+", label: "Active Students" },
    { value: "950+", label: "Passes This Month" },
    { value: "12", label: "Routes Available" },
    { value: "24/7", label: "Support" },
  ];

  return (
    <div className="min-h-screen bg-white">
      <Navbar />

      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-br from-indigo-600 via-purple-600 to-indigo-800">
        {/* Animated Campus Scene - Live Animation */}
        <AnimatedCampusScene />
        
        {/* Animated Background Elements */}
        <div className="absolute inset-0 overflow-hidden">
          <motion.div
            className="absolute top-20 -left-20 w-72 h-72 bg-white rounded-full blur-3xl opacity-10"
            animate={{
              scale: [1, 1.2, 1],
              x: [0, 50, 0],
            }}
            transition={{
              duration: 8,
              repeat: Infinity,
              ease: "easeInOut",
            }}
          />
          <motion.div
            className="absolute bottom-20 -right-20 w-96 h-96 bg-amber-300 rounded-full blur-3xl opacity-10"
            animate={{
              scale: [1, 1.3, 1],
              x: [0, -30, 0],
            }}
            transition={{
              duration: 10,
              repeat: Infinity,
              ease: "easeInOut",
            }}
          />
        </div>

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 md:py-32">
          <div className="text-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="mb-6"
            >
              <span className="inline-flex items-center gap-2 px-4 py-2 bg-white/10 backdrop-blur-sm rounded-full text-white text-sm font-medium border border-white/20">
                <Sparkles className="w-4 h-4" />
                Smart Campus Transportation
              </span>
            </motion.div>

            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.1 }}
              className="text-5xl md:text-6xl lg:text-7xl font-bold text-white mb-6 leading-tight"
            >
              Your Journey
              <br />
              <span className="bg-gradient-to-r from-amber-300 to-amber-500 bg-clip-text text-transparent">
                Starts Here
              </span>
            </motion.h1>

            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="text-xl md:text-2xl text-indigo-100 mb-10 max-w-3xl mx-auto leading-relaxed"
            >
              Seamless, digital bus passes for the modern student. Apply online, pay securely, and travel smart.
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.3 }}
              className="flex flex-col sm:flex-row gap-4 justify-center"
            >
              <Link
                to="/student-login"
                className="group px-8 py-4 bg-white text-indigo-600 rounded-2xl font-bold hover:bg-indigo-50 transition-all shadow-2xl shadow-black/20 hover:shadow-black/30 hover:scale-105 inline-flex items-center justify-center gap-2"
              >
                Get Started
                <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </Link>
              <Link
                to="/view-pass"
                className="px-8 py-4 bg-white/10 backdrop-blur-sm text-white rounded-2xl font-bold hover:bg-white/20 transition-all border-2 border-white/20 inline-flex items-center justify-center"
              >
                View Demo Pass
              </Link>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Quick Actions Cards */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-16 relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {quickActions.map((action, index) => {
            const Icon = action.icon;
            return (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.4 + index * 0.1 }}
              >
                <Link
                  to={action.link}
                  className="block bg-white rounded-3xl p-6 shadow-lg hover:shadow-2xl transition-all hover:-translate-y-1 border border-slate-100"
                >
                  <div className={`w-14 h-14 ${action.iconBg} rounded-2xl flex items-center justify-center mb-4`}>
                    <Icon className={`w-7 h-7 ${action.iconColor}`} />
                  </div>
                  <h3 className="text-xl font-bold text-slate-900 mb-2">
                    {action.title}
                  </h3>
                  <p className="text-slate-600">{action.description}</p>
                </Link>
              </motion.div>
            );
          })}
        </div>
      </section>

      {/* Video Showcase Section - Zomato Style */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="text-center mb-12">
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
            className="text-4xl md:text-5xl font-bold text-slate-900 mb-4"
          >
            Experience the Journey
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            viewport={{ once: true }}
            className="text-xl text-slate-600 max-w-2xl mx-auto"
          >
            Join thousands of students who commute safely and conveniently every day
          </motion.p>
        </div>

        {/* Main Featured Image - Large */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.7 }}
          viewport={{ once: true }}
          className="mb-8 rounded-3xl overflow-hidden shadow-2xl group"
        >
          <div className="relative h-[500px] overflow-hidden">
            <img
              src="https://images.unsplash.com/photo-1686970832435-3bbfb84162bb?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb2xsZWdlJTIwc3R1ZGVudHMlMjBib2FyZGluZyUyMHllbGxvdyUyMHNjaG9vbCUyMGJ1c3xlbnwxfHx8fDE3NzI4OTQxMTZ8MA&ixlib=rb-4.1.0&q=80&w=1080"
              alt="Students boarding college bus"
              className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
            />
            {/* Gradient Overlay */}
            <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent" />
            
            {/* Floating Badge */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.3 }}
              viewport={{ once: true }}
              className="absolute top-6 left-6"
            >
              <div className="px-4 py-2 bg-emerald-500 text-white rounded-full font-bold text-sm shadow-lg">
                ⚡ Live Now
              </div>
            </motion.div>

            {/* Content Overlay */}
            <div className="absolute bottom-0 left-0 right-0 p-8">
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.4 }}
                viewport={{ once: true }}
              >
                <h3 className="text-4xl md:text-5xl font-bold text-white mb-3">
                  🚌 Students Boarding Made Easy
                </h3>
                <p className="text-xl text-white/90 mb-4 max-w-2xl">
                  Watch how our digital pass system streamlines the boarding process for hundreds of students daily
                </p>
                <div className="flex flex-wrap gap-3">
                  <span className="px-4 py-2 bg-white/20 backdrop-blur-md text-white rounded-full text-sm font-medium border border-white/30">
                    Digital QR Scanning
                  </span>
                  <span className="px-4 py-2 bg-white/20 backdrop-blur-md text-white rounded-full text-sm font-medium border border-white/30">
                    Quick Entry
                  </span>
                  <span className="px-4 py-2 bg-white/20 backdrop-blur-md text-white rounded-full text-sm font-medium border border-white/30">
                    Safe & Secure
                  </span>
                </div>
              </motion.div>
            </div>
          </div>
        </motion.div>

        {/* Grid of Smaller Images - Zomato Food Grid Style */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Card 1 - QR Code Scanning */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            viewport={{ once: true }}
            className="group relative rounded-3xl overflow-hidden shadow-xl hover:shadow-2xl transition-all"
          >
            <div className="relative h-80 overflow-hidden">
              <img
                src="https://images.unsplash.com/photo-1731213562305-0152c6946bdc?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzdHVkZW50JTIwc2Nhbm5pbmclMjBxciUyMGNvZGUlMjBwaG9uZSUyMHRyYW5zcG9ydGF0aW9ufGVufDF8fHx8MTc3Mjg5NDExNnww&ixlib=rb-4.1.0&q=80&w=1080"
                alt="Student scanning QR code"
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-indigo-900/90 via-indigo-900/40 to-transparent" />
              <div className="absolute bottom-0 left-0 right-0 p-6">
                <div className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center mb-3">
                  <span className="text-2xl">📱</span>
                </div>
                <h4 className="text-2xl font-bold text-white mb-2">
                  Scan & Go
                </h4>
                <p className="text-indigo-100 text-sm">
                  Just scan your digital pass and board instantly
                </p>
              </div>
            </div>
          </motion.div>

          {/* Card 2 - Campus Bus */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            viewport={{ once: true }}
            className="group relative rounded-3xl overflow-hidden shadow-xl hover:shadow-2xl transition-all"
          >
            <div className="relative h-80 overflow-hidden">
              <img
                src="https://images.unsplash.com/photo-1767455471096-fad3b4616524?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb2xsZWdlJTIwY2FtcHVzJTIwYnVzJTIwdHJhbnNwb3J0JTIwY29tbXV0ZXxlbnwxfHx8fDE3NzI4OTQxMTh8MA&ixlib=rb-4.1.0&q=80&w=1080"
                alt="College campus bus"
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-purple-900/90 via-purple-900/40 to-transparent" />
              <div className="absolute bottom-0 left-0 right-0 p-6">
                <div className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center mb-3">
                  <span className="text-2xl">🚍</span>
                </div>
                <h4 className="text-2xl font-bold text-white mb-2">
                  Modern Fleet
                </h4>
                <p className="text-purple-100 text-sm">
                  Comfortable and safe buses for your daily commute
                </p>
              </div>
            </div>
          </motion.div>

          {/* Card 3 - Students Walking */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            viewport={{ once: true }}
            className="group relative rounded-3xl overflow-hidden shadow-xl hover:shadow-2xl transition-all"
          >
            <div className="relative h-80 overflow-hidden">
              <img
                src="https://images.unsplash.com/photo-1763890763432-17c9a529da20?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzdHVkZW50cyUyMGJhY2twYWNrJTIwd2Fsa2luZyUyMGNhbXB1cyUyMG1vcm5pbmd8ZW58MXx8fHwxNzcyODk0MTE4fDA&ixlib=rb-4.1.0&q=80&w=1080"
                alt="Students with backpacks"
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-emerald-900/90 via-emerald-900/40 to-transparent" />
              <div className="absolute bottom-0 left-0 right-0 p-6">
                <div className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center mb-3">
                  <span className="text-2xl">🎒</span>
                </div>
                <h4 className="text-2xl font-bold text-white mb-2">
                  Campus Life
                </h4>
                <p className="text-emerald-100 text-sm">
                  Connecting students across all campus locations
                </p>
              </div>
            </div>
          </motion.div>
        </div>

        {/* Bottom Banner with Digital Pass Preview */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.4 }}
          viewport={{ once: true }}
          className="mt-8 relative rounded-3xl overflow-hidden shadow-xl"
        >
          <div className="relative h-64 flex items-center justify-center bg-gradient-to-br from-amber-50 via-amber-100 to-amber-200">
            <img
              src="https://images.unsplash.com/photo-1696334025376-cb8e411ea7ab?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkaWdpdGFsJTIwYnVzJTIwcGFzcyUyMG1vYmlsZSUyMGFwcCUyMHNjcmVlbnxlbnwxfHx8fDE3NzI4OTQxMTl8MA&ixlib=rb-4.1.0&q=80&w=1080"
              alt="Digital bus pass on mobile"
              className="absolute inset-0 w-full h-full object-cover opacity-30"
            />
            <div className="relative z-10 text-center px-6">
              <div className="inline-flex items-center gap-3 px-6 py-3 bg-white rounded-full shadow-lg mb-4">
                <Bus className="w-6 h-6 text-indigo-600" />
                <span className="font-bold text-slate-900">100% Digital Experience</span>
              </div>
              <h3 className="text-3xl font-bold text-slate-900 mb-2">
                Your Pass, Always in Your Pocket
              </h3>
              <p className="text-slate-700 text-lg">
                No physical cards needed - everything on your phone
              </p>
            </div>
          </div>
        </motion.div>

        {/* Stats Info */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.5 }}
          viewport={{ once: true }}
          className="mt-12 text-center"
        >
          <div className="inline-flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-indigo-50 to-purple-50 rounded-full border-2 border-indigo-200">
            <span className="text-slate-700 font-semibold">
              ⭐ 12+ routes • 1,200+ active students • 98% satisfaction rate
            </span>
          </div>
        </motion.div>
      </section>

      {/* Stats Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="bg-gradient-to-br from-slate-900 to-slate-800 rounded-3xl p-12 shadow-2xl">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            {stats.map((stat, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, scale: 0.8 }}
                whileInView={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true }}
              >
                <div className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-amber-300 to-amber-500 bg-clip-text text-transparent mb-2">
                  {stat.value}
                </div>
                <div className="text-slate-400 font-medium">{stat.label}</div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-slate-900 mb-4">
            Why Choose Us?
          </h2>
          <p className="text-xl text-slate-600 max-w-2xl mx-auto">
            Experience the future of campus transportation with our innovative digital pass system
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {features.map((feature, index) => {
            const Icon = feature.icon;
            return (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true }}
                className="bg-gradient-to-br from-slate-50 to-white rounded-3xl p-8 border border-slate-200 hover:shadow-xl transition-shadow"
              >
                <div className="w-14 h-14 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-2xl flex items-center justify-center mb-6">
                  <Icon className="w-7 h-7 text-white" />
                </div>
                <h3 className="text-2xl font-bold text-slate-900 mb-3">
                  {feature.title}
                </h3>
                <p className="text-slate-600 leading-relaxed">
                  {feature.description}
                </p>
              </motion.div>
            );
          })}
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-gradient-to-r from-indigo-600 to-purple-600 py-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
              Ready to Get Started?
            </h2>
            <p className="text-xl text-indigo-100 mb-10">
              Join thousands of students already using College Bus Pass
            </p>
            <Link
              to="/student-registration"
              className="inline-flex items-center gap-2 px-8 py-4 bg-white text-indigo-600 rounded-2xl font-bold hover:bg-indigo-50 transition-all shadow-2xl hover:scale-105"
            >
              Create Your Account
              <ArrowRight className="w-5 h-5" />
            </Link>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-slate-900 text-slate-400 py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row justify-between items-center gap-6">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-xl flex items-center justify-center">
                <Bus className="w-6 h-6 text-white" />
              </div>
              <div>
                <div className="font-bold text-white text-lg">College Bus Pass</div>
                <div className="text-xs text-slate-500">Smart Campus Travel</div>
              </div>
            </div>
            <div className="text-sm text-center">
              © 2026 College Transportation. All rights reserved.
            </div>
            <div className="flex gap-6 text-sm">
              <Link to="#" className="hover:text-white transition-colors">
                Privacy
              </Link>
              <Link to="#" className="hover:text-white transition-colors">
                Terms
              </Link>
              <Link to="#" className="hover:text-white transition-colors">
                Support
              </Link>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}