import { Header } from "../components/Header";
import { Footer } from "../components/Footer";
import { useParams, useNavigate } from "react-router";
import { Calendar, CreditCard, Shield, ArrowLeft, CheckCircle } from "lucide-react";
import { useState } from "react";

export function BookingPage() {
  const { passType } = useParams();
  const navigate = useNavigate();
  const [bookingComplete, setBookingComplete] = useState(false);

  const passDetails: Record<string, any> = {
    daily: {
      name: "Daily Pass",
      price: 5,
      duration: "24 Hours",
      icon: "🎫",
      features: [
        "Valid for 24 hours from activation",
        "Unlimited rides on all routes",
        "No blackout dates",
        "Instant digital pass",
      ],
    },
    weekly: {
      name: "Weekly Pass",
      price: 25,
      duration: "7 Days",
      icon: "📅",
      features: [
        "Valid for 7 consecutive days",
        "Unlimited rides on all routes",
        "Save 30% compared to daily",
        "Free pass replacement",
      ],
    },
    monthly: {
      name: "Monthly Pass",
      price: 80,
      duration: "30 Days",
      icon: "📆",
      features: [
        "Valid for 30 consecutive days",
        "Unlimited rides on all routes",
        "Save 50% compared to daily",
        "Priority customer support",
      ],
    },
    student: {
      name: "Student Pass",
      price: 40,
      duration: "30 Days",
      icon: "🎓",
      features: [
        "Valid student ID required",
        "Unlimited rides on all routes",
        "50% discount on regular price",
        "Campus to city routes included",
      ],
    },
  };

  const pass = passDetails[passType || ""] || passDetails.daily;
  const tax = (pass.price * 0.1).toFixed(2);
  const total = (pass.price + parseFloat(tax)).toFixed(2);

  const handleBooking = (e: React.FormEvent) => {
    e.preventDefault();
    setBookingComplete(true);
    setTimeout(() => {
      navigate("/my-passes");
    }, 3000);
  };

  if (bookingComplete) {
    return (
      <div className="min-h-screen bg-gray-50 flex flex-col">
        <Header />
        <div className="flex-1 flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-lg p-12 max-w-md text-center">
            <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <CheckCircle className="w-12 h-12 text-green-600" />
            </div>
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Booking Successful!
            </h2>
            <p className="text-gray-600 mb-6">
              Your {pass.name} has been purchased successfully. You will be
              redirected to your passes page.
            </p>
            <div className="text-6xl mb-4">{pass.icon}</div>
            <p className="text-sm text-gray-500">
              Pass ID: BP{Math.random().toString(36).substr(2, 9).toUpperCase()}
            </p>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <Header />

      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <button
          onClick={() => navigate(-1)}
          className="flex items-center gap-2 text-gray-600 hover:text-red-600 mb-6 transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
          Back
        </button>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Booking Form */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-xl shadow-md p-6 mb-6">
              <h2 className="text-2xl font-bold text-gray-900 mb-6">
                Passenger Information
              </h2>
              <form onSubmit={handleBooking}>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      First Name *
                    </label>
                    <input
                      type="text"
                      required
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
                      placeholder="John"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Last Name *
                    </label>
                    <input
                      type="text"
                      required
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
                      placeholder="Doe"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Email *
                    </label>
                    <input
                      type="email"
                      required
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
                      placeholder="john.doe@example.com"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Phone Number *
                    </label>
                    <input
                      type="tel"
                      required
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
                      placeholder="+1 (555) 123-4567"
                    />
                  </div>
                </div>

                {passType === "student" && (
                  <div className="mb-6">
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Student ID Number *
                    </label>
                    <input
                      type="text"
                      required
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
                      placeholder="Enter your student ID"
                    />
                  </div>
                )}

                <div className="mb-6">
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    <Calendar className="inline w-4 h-4 mr-1" />
                    Pass Start Date *
                  </label>
                  <input
                    type="date"
                    required
                    min={new Date().toISOString().split("T")[0]}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
                  />
                  <p className="text-sm text-gray-500 mt-1">
                    Your pass will be valid from this date
                  </p>
                </div>

                <div className="border-t border-gray-200 pt-6">
                  <h3 className="text-xl font-bold text-gray-900 mb-4">
                    Payment Details
                  </h3>

                  <div className="mb-4">
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Card Number *
                    </label>
                    <div className="relative">
                      <CreditCard className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                      <input
                        type="text"
                        required
                        placeholder="1234 5678 9012 3456"
                        className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4 mb-6">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Expiry Date *
                      </label>
                      <input
                        type="text"
                        required
                        placeholder="MM/YY"
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        CVV *
                      </label>
                      <input
                        type="text"
                        required
                        placeholder="123"
                        maxLength={3}
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
                      />
                    </div>
                  </div>

                  <div className="mb-6">
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Cardholder Name *
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="John Doe"
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
                    />
                  </div>

                  <div className="flex items-start gap-2 mb-6">
                    <input
                      type="checkbox"
                      required
                      id="terms"
                      className="mt-1 rounded text-red-600"
                    />
                    <label htmlFor="terms" className="text-sm text-gray-600">
                      I agree to the terms and conditions and the refund policy
                    </label>
                  </div>

                  <button
                    type="submit"
                    className="w-full px-6 py-4 bg-red-600 text-white rounded-lg font-semibold hover:bg-red-700 transition-colors text-lg"
                  >
                    Complete Purchase - ${total}
                  </button>
                </div>
              </form>
            </div>

            {/* Security Notice */}
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 flex items-start gap-3">
              <Shield className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
              <div>
                <h4 className="font-semibold text-blue-900 mb-1">
                  Secure Payment
                </h4>
                <p className="text-sm text-blue-700">
                  Your payment information is encrypted and secure. We never
                  store your card details.
                </p>
              </div>
            </div>
          </div>

          {/* Order Summary */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-xl shadow-md p-6 sticky top-24">
              <h3 className="text-xl font-bold text-gray-900 mb-6">
                Order Summary
              </h3>

              <div className="flex items-center gap-4 mb-6 pb-6 border-b border-gray-200">
                <div className="text-5xl">{pass.icon}</div>
                <div>
                  <h4 className="font-semibold text-gray-900">{pass.name}</h4>
                  <p className="text-sm text-gray-600">{pass.duration}</p>
                </div>
              </div>

              <div className="space-y-3 mb-6">
                <h5 className="font-semibold text-gray-900 text-sm">
                  Includes:
                </h5>
                {pass.features.map((feature: string, index: number) => (
                  <div
                    key={index}
                    className="flex items-start gap-2 text-sm text-gray-600"
                  >
                    <CheckCircle className="w-4 h-4 text-green-600 flex-shrink-0 mt-0.5" />
                    <span>{feature}</span>
                  </div>
                ))}
              </div>

              <div className="border-t border-gray-200 pt-6 space-y-3">
                <div className="flex justify-between text-gray-600">
                  <span>Pass Price</span>
                  <span>${pass.price.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-gray-600">
                  <span>Tax (10%)</span>
                  <span>${tax}</span>
                </div>
                <div className="flex justify-between text-xl font-bold text-gray-900 pt-3 border-t border-gray-200">
                  <span>Total</span>
                  <span>${total}</span>
                </div>
              </div>

              <div className="mt-6 pt-6 border-t border-gray-200">
                <div className="flex items-center gap-2 text-sm text-gray-600 mb-2">
                  <CheckCircle className="w-4 h-4 text-green-600" />
                  <span>Instant digital pass delivery</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-gray-600 mb-2">
                  <CheckCircle className="w-4 h-4 text-green-600" />
                  <span>24/7 customer support</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <CheckCircle className="w-4 h-4 text-green-600" />
                  <span>Easy refund within 24 hours</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
}
