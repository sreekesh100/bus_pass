import { Header } from "../components/Header";
import { Footer } from "../components/Footer";
import { Filter, Search, Star, Users, Clock, MapPin } from "lucide-react";
import { Link } from "react-router";
import { useState } from "react";

export function PassesPage() {
  const [selectedCategory, setSelectedCategory] = useState("all");

  const allPasses = [
    {
      id: "daily",
      name: "Daily Pass",
      category: "regular",
      price: 5,
      duration: "24 Hours",
      description: "Perfect for occasional travelers and tourists",
      icon: "🎫",
      rating: 4.5,
      users: "2.3k",
      features: [
        "Valid for 24 hours from activation",
        "Unlimited rides on all routes",
        "No blackout dates",
        "Instant digital pass",
      ],
      popular: false,
    },
    {
      id: "weekly",
      name: "Weekly Pass",
      category: "regular",
      price: 25,
      duration: "7 Days",
      description: "Best value for regular commuters",
      icon: "📅",
      rating: 4.8,
      users: "5.1k",
      features: [
        "Valid for 7 consecutive days",
        "Unlimited rides on all routes",
        "Save 30% compared to daily",
        "Free pass replacement",
      ],
      popular: true,
    },
    {
      id: "monthly",
      name: "Monthly Pass",
      category: "regular",
      price: 80,
      duration: "30 Days",
      description: "Maximum savings for daily commuters",
      icon: "📆",
      rating: 4.9,
      users: "12.5k",
      features: [
        "Valid for 30 consecutive days",
        "Unlimited rides on all routes",
        "Save 50% compared to daily",
        "Priority customer support",
      ],
      popular: true,
    },
    {
      id: "student",
      name: "Student Pass",
      category: "discounted",
      price: 40,
      duration: "30 Days",
      description: "Special rates for students with valid ID",
      icon: "🎓",
      rating: 4.7,
      users: "8.2k",
      features: [
        "Valid student ID required",
        "Unlimited rides on all routes",
        "50% discount on regular price",
        "Campus to city routes included",
      ],
      popular: true,
    },
    {
      id: "senior",
      name: "Senior Citizen Pass",
      category: "discounted",
      price: 45,
      duration: "30 Days",
      description: "Discounted rates for seniors (60+)",
      icon: "👴",
      rating: 4.6,
      users: "3.8k",
      features: [
        "For passengers 60 years and above",
        "Unlimited rides on all routes",
        "44% discount on regular price",
        "Medical center routes included",
      ],
      popular: false,
    },
    {
      id: "tourist",
      name: "Tourist Pass",
      category: "special",
      price: 15,
      duration: "3 Days",
      description: "Explore the city with unlimited travel",
      icon: "🗺️",
      rating: 4.4,
      users: "1.9k",
      features: [
        "Valid for 3 consecutive days",
        "All tourist route access",
        "City guide included",
        "Museum discounts",
      ],
      popular: false,
    },
    {
      id: "weekend",
      name: "Weekend Pass",
      category: "special",
      price: 12,
      duration: "Weekend",
      description: "Unlimited rides on Saturday and Sunday",
      icon: "🎉",
      rating: 4.3,
      users: "4.2k",
      features: [
        "Valid Saturday-Sunday",
        "Unlimited rides on all routes",
        "Perfect for weekend trips",
        "Family discounts available",
      ],
      popular: false,
    },
    {
      id: "corporate",
      name: "Corporate Pass",
      category: "special",
      price: 200,
      duration: "10 Passes",
      description: "Bulk passes for organizations",
      icon: "💼",
      rating: 4.7,
      users: "982",
      features: [
        "10 monthly passes included",
        "Employee management portal",
        "Volume discounts",
        "Dedicated account manager",
      ],
      popular: false,
    },
  ];

  const categories = [
    { id: "all", name: "All Passes", count: allPasses.length },
    {
      id: "regular",
      name: "Regular",
      count: allPasses.filter((p) => p.category === "regular").length,
    },
    {
      id: "discounted",
      name: "Discounted",
      count: allPasses.filter((p) => p.category === "discounted").length,
    },
    {
      id: "special",
      name: "Special",
      count: allPasses.filter((p) => p.category === "special").length,
    },
  ];

  const filteredPasses =
    selectedCategory === "all"
      ? allPasses
      : allPasses.filter((pass) => pass.category === selectedCategory);

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <Header />

      {/* Page Header */}
      <section className="bg-gradient-to-r from-red-600 to-red-700 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="text-4xl font-bold mb-4">Browse Bus Passes</h1>
          <p className="text-xl text-red-50">
            Find the perfect pass for your travel needs
          </p>
        </div>
      </section>

      {/* Search and Filter */}
      <section className="bg-white shadow-md sticky top-16 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex flex-col md:flex-row gap-4 items-center">
            <div className="flex-1 relative w-full">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input
                type="text"
                placeholder="Search passes..."
                className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
              />
            </div>
            <button className="flex items-center gap-2 px-6 py-3 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors">
              <Filter className="w-5 h-5" />
              <span>Filters</span>
            </button>
          </div>
        </div>
      </section>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Sidebar - Categories */}
          <aside className="lg:w-64 flex-shrink-0">
            <div className="bg-white rounded-lg shadow-md p-6 sticky top-32">
              <h3 className="font-semibold text-gray-900 mb-4">Categories</h3>
              <div className="space-y-2">
                {categories.map((category) => (
                  <button
                    key={category.id}
                    onClick={() => setSelectedCategory(category.id)}
                    className={`w-full text-left px-4 py-3 rounded-lg transition-colors ${
                      selectedCategory === category.id
                        ? "bg-red-600 text-white"
                        : "bg-gray-50 text-gray-700 hover:bg-gray-100"
                    }`}
                  >
                    <div className="flex justify-between items-center">
                      <span>{category.name}</span>
                      <span className="text-sm">{category.count}</span>
                    </div>
                  </button>
                ))}
              </div>

              <div className="mt-8 pt-6 border-t border-gray-200">
                <h3 className="font-semibold text-gray-900 mb-4">
                  Price Range
                </h3>
                <div className="space-y-2">
                  <label className="flex items-center gap-2">
                    <input type="checkbox" className="rounded text-red-600" />
                    <span className="text-sm text-gray-700">Under $10</span>
                  </label>
                  <label className="flex items-center gap-2">
                    <input type="checkbox" className="rounded text-red-600" />
                    <span className="text-sm text-gray-700">$10 - $50</span>
                  </label>
                  <label className="flex items-center gap-2">
                    <input type="checkbox" className="rounded text-red-600" />
                    <span className="text-sm text-gray-700">$50 - $100</span>
                  </label>
                  <label className="flex items-center gap-2">
                    <input type="checkbox" className="rounded text-red-600" />
                    <span className="text-sm text-gray-700">Above $100</span>
                  </label>
                </div>
              </div>
            </div>
          </aside>

          {/* Main Content - Pass Grid */}
          <main className="flex-1">
            <div className="mb-6 flex justify-between items-center">
              <p className="text-gray-600">
                Showing {filteredPasses.length} passes
              </p>
              <select className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent">
                <option>Most Popular</option>
                <option>Price: Low to High</option>
                <option>Price: High to Low</option>
                <option>Highest Rated</option>
              </select>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {filteredPasses.map((pass) => (
                <div
                  key={pass.id}
                  className="bg-white rounded-xl shadow-md hover:shadow-xl transition-shadow border border-gray-100 overflow-hidden"
                >
                  {pass.popular && (
                    <div className="bg-red-600 text-white text-sm font-semibold px-4 py-2">
                      ⭐ Most Popular
                    </div>
                  )}
                  <div className="p-6">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex items-center gap-3">
                        <div className="text-4xl">{pass.icon}</div>
                        <div>
                          <h3 className="text-xl font-bold text-gray-900">
                            {pass.name}
                          </h3>
                          <div className="flex items-center gap-2 mt-1">
                            <div className="flex items-center gap-1">
                              <Star className="w-4 h-4 text-yellow-400 fill-yellow-400" />
                              <span className="text-sm text-gray-600">
                                {pass.rating}
                              </span>
                            </div>
                            <span className="text-gray-300">•</span>
                            <div className="flex items-center gap-1">
                              <Users className="w-4 h-4 text-gray-400" />
                              <span className="text-sm text-gray-600">
                                {pass.users}
                              </span>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-3xl font-bold text-red-600">
                          ${pass.price}
                        </div>
                        <div className="text-sm text-gray-600">
                          {pass.duration}
                        </div>
                      </div>
                    </div>

                    <p className="text-gray-600 mb-4">{pass.description}</p>

                    <div className="space-y-2 mb-6">
                      {pass.features.map((feature, index) => (
                        <div
                          key={index}
                          className="flex items-start gap-2 text-sm text-gray-600"
                        >
                          <div className="w-1.5 h-1.5 bg-red-600 rounded-full mt-1.5 flex-shrink-0"></div>
                          <span>{feature}</span>
                        </div>
                      ))}
                    </div>

                    <Link
                      to={`/book/${pass.id}`}
                      className="block w-full px-6 py-3 bg-red-600 text-white rounded-lg font-semibold text-center hover:bg-red-700 transition-colors"
                    >
                      Buy Now
                    </Link>
                  </div>
                </div>
              ))}
            </div>
          </main>
        </div>
      </div>

      <Footer />
    </div>
  );
}
