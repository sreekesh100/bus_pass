import { Navbar } from "../components/Navbar";
import { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router";
import {
  Calendar,
  MapPin,
  Bus,
  Ticket,
  Download,
  Printer,
  CheckCircle,
  ArrowLeft,
} from "lucide-react";
import { authAPI, mockData } from "../utils/api";
import { motion } from "motion/react";
import { QRCodeSVG } from "qrcode.react";

export function BookDayTicketPage() {
  const navigate = useNavigate();
  const [currentUser, setCurrentUser] = useState<any>(null);
  const [selectedRoute, setSelectedRoute] = useState("");
  const [selectedStop, setSelectedStop] = useState("");
  const [selectedDate, setSelectedDate] = useState("");
  const [bookedTicket, setBookedTicket] = useState<any>(null);
  const ticketRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const user = authAPI.getCurrentUser();
    if (!user || user.role !== "student") {
      navigate("/login");
      return;
    }
    setCurrentUser(user);
  }, [navigate]);

  if (!currentUser) {
    return null;
  }

  const availableStops = selectedRoute
    ? mockData.stops.filter((s) => s.route_id === parseInt(selectedRoute))
    : [];

  const handleBookTicket = () => {
    if (!selectedRoute || !selectedStop || !selectedDate) {
      alert("Please fill in all fields");
      return;
    }

    const route = mockData.routes.find((r) => r.route_id === parseInt(selectedRoute));
    const stop = mockData.stops.find((s) => s.stop_id === parseInt(selectedStop));

    const newTicket = {
      ticket_id: Math.floor(Math.random() * 10000),
      student_id: currentUser.student_id,
      student_name: currentUser.studentData.name,
      route_id: parseInt(selectedRoute),
      route_name: route?.route_name,
      stop_id: parseInt(selectedStop),
      stop_name: stop?.stop_name,
      travel_date: selectedDate,
      booking_date: new Date().toISOString().split("T")[0],
      status: "Active",
      amount: 50,
      qr_code: `TICKET-${currentUser.student_id}-${Date.now()}`,
    };

    setBookedTicket(newTicket);
  };

  const handlePrint = () => {
    if (ticketRef.current) {
      const printWindow = window.open("", "_blank");
      if (printWindow) {
        printWindow.document.write(`
          <html>
            <head>
              <title>Bus Ticket - ${bookedTicket.ticket_id}</title>
              <style>
                body {
                  font-family: Arial, sans-serif;
                  padding: 20px;
                  margin: 0;
                }
                .ticket-print {
                  max-width: 600px;
                  margin: 0 auto;
                  padding: 30px;
                  border: 2px dashed #333;
                  border-radius: 10px;
                }
                h1 { color: #333; text-align: center; }
                .ticket-info { margin: 20px 0; }
                .ticket-row { display: flex; justify-content: space-between; padding: 10px 0; border-bottom: 1px solid #eee; }
                .ticket-label { font-weight: bold; color: #666; }
                .qr-container { text-align: center; margin: 20px 0; }
                @media print {
                  body { padding: 0; }
                }
              </style>
            </head>
            <body>
              ${ticketRef.current.innerHTML}
            </body>
          </html>
        `);
        printWindow.document.close();
        printWindow.print();
      }
    }
  };

  const handleDownload = () => {
    alert("Ticket downloaded! (Mock implementation)");
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString("en-US", {
      year: "numeric",
      month: "long",
      day: "numeric",
    });
  };

  if (bookedTicket) {
    return (
      <div className="min-h-screen bg-slate-50">
        <Navbar />

        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="text-center mb-8"
          >
            <div className="w-20 h-20 bg-gradient-to-br from-emerald-400 to-emerald-600 rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg">
              <CheckCircle className="w-10 h-10 text-white" />
            </div>
            <h1 className="text-3xl font-bold text-slate-900 mb-2">
              Booking Successful! 🎉
            </h1>
            <p className="text-slate-600">
              Your day ticket has been booked successfully
            </p>
          </motion.div>

          {/* Ticket Display */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            ref={ticketRef}
            className="bg-white rounded-3xl shadow-2xl overflow-hidden mb-6"
          >
            {/* Ticket Header */}
            <div className="bg-gradient-to-r from-indigo-600 to-purple-600 p-8 text-white">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <p className="text-indigo-100 text-sm mb-1">Bus Day Ticket</p>
                  <h2 className="text-3xl font-bold">#{bookedTicket.ticket_id}</h2>
                </div>
                <div className="w-16 h-16 bg-white/20 backdrop-blur-sm rounded-2xl flex items-center justify-center">
                  <Ticket className="w-8 h-8 text-white" />
                </div>
              </div>

              <div className="bg-white/10 backdrop-blur-sm rounded-2xl px-4 py-2 inline-block">
                <p className="text-sm font-semibold">Status: Active</p>
              </div>
            </div>

            {/* Ticket Body */}
            <div className="p-8">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                {/* Left Column - Info */}
                <div className="space-y-4">
                  <div>
                    <p className="text-sm text-slate-600 mb-1">Passenger Name</p>
                    <p className="text-lg font-bold text-slate-900">
                      {bookedTicket.student_name}
                    </p>
                  </div>

                  <div>
                    <p className="text-sm text-slate-600 mb-1">Student ID</p>
                    <p className="text-lg font-bold text-slate-900">
                      {bookedTicket.student_id}
                    </p>
                  </div>

                  <div className="flex items-start gap-3">
                    <Bus className="w-5 h-5 text-indigo-600 mt-1" />
                    <div>
                      <p className="text-sm text-slate-600 mb-1">Route</p>
                      <p className="font-semibold text-slate-900">
                        {bookedTicket.route_name}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <MapPin className="w-5 h-5 text-indigo-600 mt-1" />
                    <div>
                      <p className="text-sm text-slate-600 mb-1">Boarding Stop</p>
                      <p className="font-semibold text-slate-900">
                        {bookedTicket.stop_name}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <Calendar className="w-5 h-5 text-indigo-600 mt-1" />
                    <div>
                      <p className="text-sm text-slate-600 mb-1">Travel Date</p>
                      <p className="font-semibold text-slate-900">
                        {formatDate(bookedTicket.travel_date)}
                      </p>
                    </div>
                  </div>
                </div>

                {/* Right Column - QR Code */}
                <div className="flex flex-col items-center justify-center bg-slate-50 rounded-2xl p-6">
                  <p className="text-sm text-slate-600 mb-4 font-medium">
                    Scan QR Code for Verification
                  </p>
                  <div className="bg-white p-4 rounded-2xl shadow-lg">
                    <QRCodeSVG
                      value={bookedTicket.qr_code}
                      size={200}
                      level="H"
                      includeMargin={true}
                    />
                  </div>
                  <p className="text-xs text-slate-500 mt-4 text-center">
                    Ticket ID: {bookedTicket.ticket_id}
                  </p>
                </div>
              </div>

              {/* Ticket Footer */}
              <div className="border-t border-slate-200 pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-slate-600 mb-1">Amount Paid</p>
                    <p className="text-3xl font-bold text-emerald-600">
                      ₹{bookedTicket.amount}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm text-slate-600 mb-1">Booking Date</p>
                    <p className="font-semibold text-slate-900">
                      {formatDate(bookedTicket.booking_date)}
                    </p>
                  </div>
                </div>
              </div>

              {/* Important Notice */}
              <div className="mt-6 bg-amber-50 border border-amber-200 rounded-2xl p-4">
                <p className="text-sm text-amber-800">
                  <strong>Important:</strong> Please show this QR code to the bus driver
                  before boarding. This ticket is valid only for the selected date and route.
                </p>
              </div>
            </div>
          </motion.div>

          {/* Action Buttons */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="flex flex-wrap gap-4 justify-center"
          >
            <button
              onClick={handlePrint}
              className="flex items-center gap-2 px-6 py-3 bg-indigo-600 text-white rounded-2xl font-semibold hover:bg-indigo-700 transition-all shadow-md"
            >
              <Printer className="w-5 h-5" />
              Print Ticket
            </button>

            <button
              onClick={handleDownload}
              className="flex items-center gap-2 px-6 py-3 bg-emerald-600 text-white rounded-2xl font-semibold hover:bg-emerald-700 transition-all shadow-md"
            >
              <Download className="w-5 h-5" />
              Download PDF
            </button>

            <button
              onClick={() => navigate("/student-dashboard")}
              className="flex items-center gap-2 px-6 py-3 bg-slate-200 text-slate-900 rounded-2xl font-semibold hover:bg-slate-300 transition-all"
            >
              <ArrowLeft className="w-5 h-5" />
              Back to Dashboard
            </button>
          </motion.div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50">
      <Navbar />

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <button
            onClick={() => navigate("/student-dashboard")}
            className="flex items-center gap-2 text-slate-600 hover:text-slate-900 mb-4 font-medium"
          >
            <ArrowLeft className="w-5 h-5" />
            Back to Dashboard
          </button>

          <h1 className="text-3xl font-bold text-slate-900 mb-2">
            Book Day Ticket 🎫
          </h1>
          <p className="text-slate-600">
            Perfect for occasional travelers! Book a ticket for specific days only.
          </p>
        </motion.div>

        {/* Booking Form */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-white rounded-3xl shadow-lg p-8 border border-slate-200"
        >
          <h2 className="text-2xl font-bold text-slate-900 mb-6">
            Ticket Details
          </h2>

          <div className="space-y-6">
            {/* Student Info */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 p-4 bg-slate-50 rounded-2xl">
              <div>
                <p className="text-sm text-slate-600 mb-1">Student Name</p>
                <p className="font-semibold text-slate-900">
                  {currentUser.studentData?.name}
                </p>
              </div>
              <div>
                <p className="text-sm text-slate-600 mb-1">Student ID</p>
                <p className="font-semibold text-slate-900">
                  {currentUser.student_id}
                </p>
              </div>
            </div>

            {/* Route Selection */}
            <div>
              <label className="block text-sm font-semibold text-slate-900 mb-2">
                Select Route
              </label>
              <select
                value={selectedRoute}
                onChange={(e) => {
                  setSelectedRoute(e.target.value);
                  setSelectedStop("");
                }}
                className="w-full px-4 py-3 border border-slate-300 rounded-2xl focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
              >
                <option value="">Choose a route</option>
                {mockData.routes.map((route) => (
                  <option key={route.route_id} value={route.route_id}>
                    {route.route_name}
                  </option>
                ))}
              </select>
            </div>

            {/* Stop Selection */}
            <div>
              <label className="block text-sm font-semibold text-slate-900 mb-2">
                Select Boarding Stop
              </label>
              <select
                value={selectedStop}
                onChange={(e) => setSelectedStop(e.target.value)}
                disabled={!selectedRoute}
                className="w-full px-4 py-3 border border-slate-300 rounded-2xl focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent disabled:bg-slate-100 disabled:cursor-not-allowed"
              >
                <option value="">Choose a stop</option>
                {availableStops.map((stop) => (
                  <option key={stop.stop_id} value={stop.stop_id}>
                    {stop.stop_name}
                  </option>
                ))}
              </select>
            </div>

            {/* Date Selection */}
            <div>
              <label className="block text-sm font-semibold text-slate-900 mb-2">
                Travel Date
              </label>
              <input
                type="date"
                value={selectedDate}
                onChange={(e) => setSelectedDate(e.target.value)}
                min={new Date().toISOString().split("T")[0]}
                className="w-full px-4 py-3 border border-slate-300 rounded-2xl focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
              />
            </div>

            {/* Pricing Info */}
            <div className="bg-gradient-to-r from-emerald-50 to-teal-50 border border-emerald-200 rounded-2xl p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-slate-600 mb-1">Ticket Price</p>
                  <p className="text-3xl font-bold text-emerald-600">₹50</p>
                </div>
                <div className="text-right">
                  <p className="text-sm text-emerald-700 font-medium">
                    Single Day Pass
                  </p>
                  <p className="text-xs text-slate-600">Valid for selected date only</p>
                </div>
              </div>
            </div>

            {/* Book Button */}
            <button
              onClick={handleBookTicket}
              disabled={!selectedRoute || !selectedStop || !selectedDate}
              className="w-full py-4 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-2xl font-bold hover:from-indigo-700 hover:to-purple-700 transition-all shadow-lg disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Book Ticket for ₹50
            </button>
          </div>
        </motion.div>

        {/* Benefits Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-6"
        >
          <div className="bg-white rounded-2xl shadow-md p-6 border border-slate-200">
            <div className="w-12 h-12 bg-indigo-100 rounded-xl flex items-center justify-center mb-4">
              <Ticket className="w-6 h-6 text-indigo-600" />
            </div>
            <h3 className="font-bold text-slate-900 mb-2">Instant Booking</h3>
            <p className="text-sm text-slate-600">
              Get your ticket immediately with QR code
            </p>
          </div>

          <div className="bg-white rounded-2xl shadow-md p-6 border border-slate-200">
            <div className="w-12 h-12 bg-emerald-100 rounded-xl flex items-center justify-center mb-4">
              <CheckCircle className="w-6 h-6 text-emerald-600" />
            </div>
            <h3 className="font-bold text-slate-900 mb-2">No Commitment</h3>
            <p className="text-sm text-slate-600">
              Pay only for the days you need
            </p>
          </div>

          <div className="bg-white rounded-2xl shadow-md p-6 border border-slate-200">
            <div className="w-12 h-12 bg-amber-100 rounded-xl flex items-center justify-center mb-4">
              <Calendar className="w-6 h-6 text-amber-600" />
            </div>
            <h3 className="font-bold text-slate-900 mb-2">Flexible Dates</h3>
            <p className="text-sm text-slate-600">
              Choose any date that works for you
            </p>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
