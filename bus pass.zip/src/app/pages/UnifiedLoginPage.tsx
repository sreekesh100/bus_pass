import React from "react";
import { Navbar } from "../components/Navbar";
import { Link, useNavigate } from "react-router";
import { User, Lock, Mail, Facebook, Chrome, Apple, X, Shield } from "lucide-react";
import { motion } from "motion/react";
import { RoleSwitch } from "../components/RoleSwitch";
import { authAPI } from "../utils/api";

export function UnifiedLoginPage() {
  const navigate = useNavigate();
  const [activeRole, setActiveRole] = React.useState<'student' | 'admin'>('student');
  const [formData, setFormData] = React.useState({
    email: "",
    password: "",
  });
  const [error, setError] = React.useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    
    if (formData.email && formData.password) {
      const result = authAPI.login(formData.email, formData.password, activeRole);
      
      if (result.success) {
        console.log(`${activeRole} Login successful:`, result.user);
        
        if (activeRole === 'student') {
          navigate("/student-dashboard");
        } else {
          navigate("/admin-dashboard");
        }
      } else {
        setError("Invalid email or password. Please try again.");
      }
    } else {
      setError("Please fill in all fields.");
    }
  };

  const socialLogins = [
    { name: "Facebook", icon: Facebook, color: "text-blue-600" },
    { name: "Google", icon: Chrome, color: "text-red-600" },
    { name: "Apple", icon: Apple, color: "text-slate-900" },
  ];

  return (
    <div className="min-h-screen bg-slate-50">
      <Navbar />

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.5 }}
        className="max-w-md mx-auto px-4 sm:px-6 lg:px-8 py-8"
      >
        {/* Close Button */}
        <div className="flex justify-end mb-4">
          <button
            onClick={() => navigate("/")}
            className="w-10 h-10 flex items-center justify-center bg-white rounded-full shadow-md hover:shadow-lg transition-all"
          >
            <X className="w-5 h-5 text-slate-600" />
          </button>
        </div>

        {/* Role Switch */}
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.1, duration: 0.5 }}
          className="flex justify-center mb-6"
        >
          <RoleSwitch activeRole={activeRole} onRoleChange={setActiveRole} />
        </motion.div>

        {/* Card */}
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.2, duration: 0.5 }}
          className="bg-white rounded-3xl shadow-xl p-8"
        >
          {/* Icon */}
          <div className={`w-16 h-16 bg-gradient-to-br rounded-2xl flex items-center justify-center mb-6 shadow-lg ${
            activeRole === 'student' 
              ? 'from-emerald-400 to-emerald-500'
              : 'from-black via-slate-900 to-black'
          }`}>
            {activeRole === 'student' ? (
              <User className="w-8 h-8 text-white" />
            ) : (
              <Shield className="w-8 h-8 text-white" />
            )}
          </div>

          {/* Title */}
          <motion.h1
            key={activeRole}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.3 }}
            className="text-3xl font-bold text-slate-900 mb-2"
          >
            {activeRole === 'student' ? 'Welcome to College Bus Pass' : 'Admin Dashboard Access'}
          </motion.h1>
          
          <motion.p
            key={`${activeRole}-subtitle`}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.3, delay: 0.1 }}
            className="text-slate-600 mb-8"
          >
            {activeRole === 'student' 
              ? 'Sign in to manage your bus pass'
              : 'Secure login for authorized personnel only'
            }
          </motion.p>

          {/* Form */}
          <form onSubmit={handleSubmit}>
            {/* Error Message */}
            {error && (
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                className="mb-6 p-4 bg-red-50 border border-red-200 rounded-2xl"
              >
                <p className="text-sm text-red-600 font-medium">{error}</p>
              </motion.div>
            )}

            {/* Email */}
            <div className="mb-6">
              <label htmlFor="email" className="block text-sm font-medium text-slate-700 mb-2">
                Email <span className="text-red-500">*</span>
              </label>
              <div className="relative">
                <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                <input
                  type="email"
                  id="email"
                  required
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="w-full pl-12 pr-4 py-3.5 border border-slate-200 rounded-2xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent transition-all text-slate-900 placeholder-slate-400"
                  placeholder={activeRole === 'student' ? 'your.email@college.edu' : 'admin@college.edu'}
                />
              </div>
            </div>

            {/* Password */}
            <div className="mb-6">
              <label htmlFor="password" className="block text-sm font-medium text-slate-700 mb-2">
                Password <span className="text-red-500">*</span>
              </label>
              <div className="relative">
                <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                <input
                  type="password"
                  id="password"
                  required
                  value={formData.password}
                  onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                  className="w-full pl-12 pr-4 py-3.5 border border-slate-200 rounded-2xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent transition-all text-slate-900 placeholder-slate-400"
                  placeholder="Enter your password"
                />
              </div>
            </div>

            {/* Forgot Password */}
            <div className="text-right mb-6">
              <Link to="#" className="text-sm text-emerald-600 font-medium hover:underline">
                Forgot password?
              </Link>
            </div>

            {/* Submit Button */}
            <motion.button
              key={`${activeRole}-button`}
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ duration: 0.2 }}
              type="submit"
              className={`w-full px-6 py-4 rounded-2xl font-semibold transition-all text-lg shadow-lg mb-6 ${
                activeRole === 'student'
                  ? 'bg-gradient-to-r from-emerald-600 to-emerald-700 hover:from-emerald-700 hover:to-emerald-800 text-white shadow-emerald-200'
                  : 'bg-gradient-to-r from-slate-900 via-black to-slate-900 hover:from-black hover:via-slate-900 hover:to-black text-white shadow-slate-300'
              }`}
            >
              {activeRole === 'student' ? 'Continue as Student' : 'Continue as Admin'}
            </motion.button>

            {/* Social Login - Only for Students */}
            {activeRole === 'student' && (
              <>
                {/* Divider */}
                <div className="relative my-6">
                  <div className="absolute inset-0 flex items-center">
                    <div className="w-full border-t border-slate-200"></div>
                  </div>
                  <div className="relative flex justify-center text-sm">
                    <span className="px-4 bg-white text-slate-500 font-medium">or</span>
                  </div>
                </div>

                {/* Social Login Buttons */}
                <div className="space-y-3">
                  {socialLogins.map((social) => {
                    const Icon = social.icon;
                    return (
                      <button
                        key={social.name}
                        type="button"
                        className="w-full px-6 py-3.5 bg-white border-2 border-slate-200 rounded-2xl font-medium text-slate-700 hover:border-slate-300 hover:bg-slate-50 transition-all flex items-center justify-center gap-3"
                      >
                        <Icon className={`w-5 h-5 ${social.color}`} />
                        Continue with {social.name}
                      </button>
                    );
                  })}
                </div>
              </>
            )}
          </form>

          {/* Footer */}
          <p className="text-sm text-slate-600 text-center mt-6">
            By continuing, you agree to our{" "}
            <a href="#" className="text-emerald-600 font-medium hover:underline">
              Privacy Policy
            </a>
          </p>

          {/* Registration Link - Only for Students */}
          {activeRole === 'student' && (
            <div className="text-center mt-6 pt-6 border-t border-slate-200">
              <p className="text-sm text-slate-600">
                Don't have an account?{" "}
                <Link to="/student-registration" className="text-emerald-600 font-semibold hover:underline">
                  Register here
                </Link>
              </p>
            </div>
          )}

          {/* Admin Notice */}
          {activeRole === 'admin' && (
            <div className="mt-6 pt-6 border-t border-slate-200">
              <div className="bg-amber-50 border border-amber-200 rounded-2xl p-4">
                <p className="text-sm text-amber-800">
                  <strong>⚠️ Admin Access:</strong> This area is restricted to authorized personnel only. 
                  Unauthorized access is prohibited.
                </p>
              </div>
            </div>
          )}
        </motion.div>

        {/* Settings Footer */}
        <div className="mt-8 flex items-center justify-between px-4">
          <span className="text-slate-600 font-medium">Settings</span>
          <button className="w-8 h-8 flex items-center justify-center text-slate-600 hover:text-slate-900">
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
            </svg>
          </button>
        </div>
      </motion.div>
    </div>
  );
}