import React from "react";
import { Navbar } from "../components/Navbar";
import { useNavigate } from "react-router";
import { Shield, Lock } from "lucide-react";

export function AdminLoginPage() {
  const navigate = useNavigate();
  const [formData, setFormData] = React.useState({
    username: "",
    password: "",
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Mock authentication - in a real app, this would validate against a backend
    if (formData.username && formData.password) {
      console.log("Admin Login:", formData);
      alert("Admin login successful! Redirecting to dashboard...");
      navigate("/admin");
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 to-slate-800">
      <Navbar />

      <div className="max-w-md mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Page Header */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-br from-slate-700 to-slate-800 rounded-2xl mb-4 shadow-2xl border-2 border-amber-400">
            <Shield className="w-10 h-10 text-amber-400" />
          </div>
          <h1 className="text-4xl font-bold text-white mb-2">
            Admin Portal
          </h1>
          <p className="text-slate-300 text-lg">
            Authorized personnel only
          </p>
        </div>

        {/* Login Form */}
        <div className="bg-white/5 backdrop-blur-xl rounded-2xl shadow-2xl p-8 border-2 border-slate-700">
          <form onSubmit={handleSubmit}>
            {/* Username */}
            <div className="mb-6">
              <label htmlFor="username" className="block text-sm font-semibold text-slate-200 mb-2">
                Admin Username
              </label>
              <input
                type="text"
                id="username"
                required
                value={formData.username}
                onChange={(e) => setFormData({ ...formData, username: e.target.value })}
                className="w-full px-4 py-3.5 bg-white/10 border border-slate-600 text-white rounded-xl focus:ring-2 focus:ring-amber-400 focus:border-transparent transition-all placeholder-slate-400"
                placeholder="Enter admin username"
              />
            </div>

            {/* Password */}
            <div className="mb-6">
              <label htmlFor="password" className="block text-sm font-semibold text-slate-200 mb-2">
                Admin Password
              </label>
              <input
                type="password"
                id="password"
                required
                value={formData.password}
                onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                className="w-full px-4 py-3.5 bg-white/10 border border-slate-600 text-white rounded-xl focus:ring-2 focus:ring-amber-400 focus:border-transparent transition-all placeholder-slate-400"
                placeholder="Enter admin password"
              />
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              className="w-full px-6 py-4 bg-gradient-to-r from-amber-500 to-amber-600 text-white rounded-xl font-semibold hover:from-amber-600 hover:to-amber-700 transition-all text-lg shadow-xl shadow-amber-900/50"
            >
              Admin Login
            </button>
          </form>

          <div className="mt-6 p-4 bg-slate-800/50 rounded-xl border border-slate-700">
            <p className="text-xs text-slate-300 text-center">
              <strong className="text-amber-400">Security Notice:</strong> Unauthorized access attempts will be logged and reported.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}