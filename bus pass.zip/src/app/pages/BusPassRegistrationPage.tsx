import { Navbar } from "../components/Navbar";
import { useState, useEffect } from "react";
import { FileText, User, MapPin, Calendar, CheckCircle, Route } from "lucide-react";
import { mockData } from "../utils/api";

export function BusPassRegistrationPage() {
  const [formData, setFormData] = useState({
    student_id: "",
    route_id: "",
    stop_id: "",
    valid_from: "",
    valid_to: "",
  });
  const [submitted, setSubmitted] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [availableStops, setAvailableStops] = useState<any[]>([]);

  // Filter stops based on selected route
  useEffect(() => {
    if (formData.route_id) {
      const filtered = mockData.stops.filter(
        (stop) => stop.route_id === parseInt(formData.route_id)
      );
      setAvailableStops(filtered);
    } else {
      setAvailableStops([]);
    }
  }, [formData.route_id]);

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    if (!formData.student_id) {
      newErrors.student_id = "Student selection is required";
    }
    if (!formData.route_id) {
      newErrors.route_id = "Route selection is required";
    }
    if (!formData.stop_id) {
      newErrors.stop_id = "Stop selection is required";
    }
    if (!formData.valid_from) {
      newErrors.valid_from = "Start date is required";
    }
    if (!formData.valid_to) {
      newErrors.valid_to = "End date is required";
    }
    if (formData.valid_from && formData.valid_to) {
      if (new Date(formData.valid_to) <= new Date(formData.valid_from)) {
        newErrors.valid_to = "End date must be after start date";
      }
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!validateForm()) {
      return;
    }

    try {
      // Mock API call - Replace with actual API endpoint
      // const response = await passAPI.create(formData);
      
      const passData = {
        ...formData,
        status: "Active",
        pass_id: Math.floor(Math.random() * 10000),
      };
      
      console.log("Bus Pass Registration Data:", passData);
      
      // Simulate API success
      setSubmitted(true);
      
      // Reset form after 3 seconds
      setTimeout(() => {
        setFormData({
          student_id: "",
          route_id: "",
          stop_id: "",
          valid_from: "",
          valid_to: "",
        });
        setSubmitted(false);
      }, 3000);
    } catch (error) {
      console.error("Pass Registration Error:", error);
      alert("Failed to register bus pass. Please try again.");
    }
  };

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    
    // Reset stop selection when route changes
    if (name === "route_id") {
      setFormData((prev) => ({ ...prev, stop_id: "" }));
    }
    
    // Clear error when user makes selection
    if (errors[name]) {
      setErrors((prev) => ({ ...prev, [name]: "" }));
    }
  };

  const getStudentName = (id: string) => {
    const student = mockData.students.find(
      (s) => s.student_id === parseInt(id)
    );
    return student ? student.name : "";
  };

  const getRouteName = (id: string) => {
    const route = mockData.routes.find((r) => r.route_id === parseInt(id));
    return route ? route.route_name : "";
  };

  if (submitted) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Navbar />
        <div className="flex items-center justify-center p-8 mt-20">
          <div className="bg-white rounded-xl shadow-lg p-12 max-w-md text-center">
            <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <CheckCircle className="w-12 h-12 text-green-600" />
            </div>
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Pass Registration Successful!
            </h2>
            <p className="text-gray-600 mb-6">
              Your bus pass has been registered successfully.
            </p>
            <div className="bg-blue-50 rounded-lg p-4 mb-6">
              <p className="text-sm text-blue-900 font-medium">
                Student: {getStudentName(formData.student_id)}
              </p>
              <p className="text-sm text-blue-900">
                Route: {getRouteName(formData.route_id)}
              </p>
              <p className="text-sm text-blue-900">
                Valid: {formData.valid_from} to {formData.valid_to}
              </p>
            </div>
            <p className="text-sm text-gray-500">Redirecting to form...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50">
      <Navbar />

      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Page Header */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-emerald-600 rounded-lg mb-4 shadow-md">
            <FileText className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-3xl font-bold text-slate-900 mb-2">
            Bus Pass Registration
          </h1>
          <p className="text-slate-600">
            Register for a new bus pass by selecting your details
          </p>
        </div>

        {/* Registration Form */}
        <div className="bg-white rounded-lg shadow-lg p-8">
          <form onSubmit={handleSubmit}>
            {/* Student Selection */}
            <div className="mb-6">
              <label className="flex items-center gap-2 text-sm font-medium text-gray-700 mb-2">
                <User className="w-4 h-4" />
                Select Student *
              </label>
              <select
                name="student_id"
                value={formData.student_id}
                onChange={handleChange}
                className={`w-full px-4 py-3 border ${
                  errors.student_id ? "border-red-500" : "border-gray-300"
                } rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent`}
              >
                <option value="">Choose a student</option>
                {mockData.students.map((student) => (
                  <option key={student.student_id} value={student.student_id}>
                    {student.name} - {student.department} ({student.year})
                  </option>
                ))}
              </select>
              {errors.student_id && (
                <p className="text-red-500 text-sm mt-1">{errors.student_id}</p>
              )}
            </div>

            {/* Route Selection */}
            <div className="mb-6">
              <label className="flex items-center gap-2 text-sm font-medium text-gray-700 mb-2">
                <Route className="w-4 h-4" />
                Select Route *
              </label>
              <select
                name="route_id"
                value={formData.route_id}
                onChange={handleChange}
                className={`w-full px-4 py-3 border ${
                  errors.route_id ? "border-red-500" : "border-gray-300"
                } rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent`}
              >
                <option value="">Choose a route</option>
                {mockData.routes.map((route) => (
                  <option key={route.route_id} value={route.route_id}>
                    {route.route_name}
                  </option>
                ))}
              </select>
              {errors.route_id && (
                <p className="text-red-500 text-sm mt-1">{errors.route_id}</p>
              )}
            </div>

            {/* Stop Selection */}
            <div className="mb-6">
              <label className="flex items-center gap-2 text-sm font-medium text-gray-700 mb-2">
                <MapPin className="w-4 h-4" />
                Select Stop *
              </label>
              <select
                name="stop_id"
                value={formData.stop_id}
                onChange={handleChange}
                disabled={!formData.route_id}
                className={`w-full px-4 py-3 border ${
                  errors.stop_id ? "border-red-500" : "border-gray-300"
                } rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent disabled:bg-gray-100 disabled:cursor-not-allowed`}
              >
                <option value="">
                  {formData.route_id
                    ? "Choose a stop"
                    : "Select a route first"}
                </option>
                {availableStops.map((stop) => (
                  <option key={stop.stop_id} value={stop.stop_id}>
                    {stop.stop_name}
                  </option>
                ))}
              </select>
              {errors.stop_id && (
                <p className="text-red-500 text-sm mt-1">{errors.stop_id}</p>
              )}
            </div>

            {/* Date Selection */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
              <div>
                <label className="flex items-center gap-2 text-sm font-medium text-gray-700 mb-2">
                  <Calendar className="w-4 h-4" />
                  Valid From *
                </label>
                <input
                  type="date"
                  name="valid_from"
                  value={formData.valid_from}
                  onChange={handleChange}
                  min={new Date().toISOString().split("T")[0]}
                  className={`w-full px-4 py-3 border ${
                    errors.valid_from ? "border-red-500" : "border-gray-300"
                  } rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent`}
                />
                {errors.valid_from && (
                  <p className="text-red-500 text-sm mt-1">
                    {errors.valid_from}
                  </p>
                )}
              </div>

              <div>
                <label className="flex items-center gap-2 text-sm font-medium text-gray-700 mb-2">
                  <Calendar className="w-4 h-4" />
                  Valid To *
                </label>
                <input
                  type="date"
                  name="valid_to"
                  value={formData.valid_to}
                  onChange={handleChange}
                  min={
                    formData.valid_from ||
                    new Date().toISOString().split("T")[0]
                  }
                  className={`w-full px-4 py-3 border ${
                    errors.valid_to ? "border-red-500" : "border-gray-300"
                  } rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent`}
                />
                {errors.valid_to && (
                  <p className="text-red-500 text-sm mt-1">{errors.valid_to}</p>
                )}
              </div>
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              className="w-full px-6 py-4 bg-amber-600 text-white rounded-lg font-semibold hover:bg-amber-700 transition-all text-lg shadow-md"
            >
              Register Bus Pass
            </button>
          </form>

          <div className="mt-6 p-4 bg-amber-50 rounded-lg border border-amber-200">
            <p className="text-sm text-gray-900">
              <strong>Note:</strong> Your bus pass will be activated from the
              selected start date and will remain valid until the end date.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}