import { Navbar } from "../components/Navbar";
import { useState } from "react";
import { FileText, MapPin, Calendar, Users, Clock, Bus, ChevronRight, Share2 } from "lucide-react";
import { motion } from "motion/react";
import { mockData } from "../utils/api";

export function ViewBusPassPage() {
  const [activeTab, setActiveTab] = useState<"upcoming" | "past">("upcoming");

  // Mock bus pass bookings
  const busPassBookings = [
    {
      id: 1,
      route: "Route 5A - Downtown",
      stop: "Main Campus Gate",
      date: "15 Mar 2026",
      time: "8:00 AM",
      validity: "30 Days",
      status: "active",
      discount: "20% off",
      promotion: "Early bird discount applied! Check your email for details.",
      shared: true,
    },
    {
      id: 2,
      route: "Route 12 - North Campus",
      stop: "Engineering Block",
      date: "1 Apr 2026",
      time: "7:30 AM",
      validity: "90 Days",
      status: "upcoming",
      shared: false,
    },
  ];

  const pastBookings = [
    {
      id: 3,
      route: "Route 3B - Library",
      stop: "Central Library Stop",
      date: "1 Jan 2026",
      time: "9:00 AM",
      validity: "30 Days",
      status: "expired",
      shared: false,
    },
  ];

  const currentBookings = activeTab === "upcoming" ? busPassBookings : pastBookings;

  return (
    <div className="min-h-screen bg-slate-50">
      <Navbar />

      <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="mb-8"
        >
          <h1 className="text-4xl font-bold text-slate-900 mb-2">My Passes</h1>
        </motion.div>

        {/* Tabs */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.1, duration: 0.5 }}
          className="mb-8"
        >
          <div className="flex gap-8 border-b-2 border-slate-200">
            <button
              onClick={() => setActiveTab("upcoming")}
              className={`pb-4 text-lg font-bold transition-colors relative ${
                activeTab === "upcoming"
                  ? "text-slate-900"
                  : "text-slate-400"
              }`}
            >
              Upcoming
              {activeTab === "upcoming" && (
                <motion.div
                  layoutId="activeTab"
                  className="absolute bottom-0 left-0 right-0 h-0.5 bg-emerald-600"
                />
              )}
            </button>
            <button
              onClick={() => setActiveTab("past")}
              className={`pb-4 text-lg font-bold transition-colors relative ${
                activeTab === "past"
                  ? "text-slate-900"
                  : "text-slate-400"
              }`}
            >
              Past
              {activeTab === "past" && (
                <motion.div
                  layoutId="activeTab"
                  className="absolute bottom-0 left-0 right-0 h-0.5 bg-emerald-600"
                />
              )}
            </button>
          </div>
        </motion.div>

        {/* Booking Cards */}
        <div className="space-y-6">
          {currentBookings.map((booking, index) => (
            <motion.div
              key={booking.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 + index * 0.1, duration: 0.5 }}
              className="bg-white rounded-3xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow"
            >
              {/* Image Header */}
              <div className="relative h-48 bg-gradient-to-br from-indigo-500 to-purple-600 overflow-hidden">
                <div className="absolute inset-0 flex items-center justify-center">
                  <Bus className="w-24 h-24 text-white opacity-20" />
                </div>
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                
                {/* Shared Badge */}
                {booking.shared && (
                  <div className="absolute top-4 left-4 flex items-center gap-2 bg-white/90 backdrop-blur-sm px-3 py-1.5 rounded-full">
                    <Share2 className="w-4 h-4 text-slate-700" />
                    <span className="text-sm font-semibold text-slate-700">Shared</span>
                  </div>
                )}

                {/* Route Name */}
                <div className="absolute bottom-4 left-4 right-4">
                  <h2 className="text-2xl font-bold text-white mb-1">
                    {booking.route}
                  </h2>
                </div>
              </div>

              {/* Details */}
              <div className="p-6">
                {/* Info Grid */}
                <div className="grid grid-cols-2 gap-4 mb-5">
                  <div className="flex items-center gap-2 text-slate-600">
                    <Calendar className="w-5 h-5" />
                    <span className="font-medium">{booking.date}</span>
                  </div>
                  <div className="flex items-center gap-2 text-slate-600">
                    <Clock className="w-5 h-5" />
                    <span className="font-medium">{booking.time}</span>
                  </div>
                  <div className="flex items-center gap-2 text-slate-600">
                    <MapPin className="w-5 h-5" />
                    <span className="font-medium text-sm">{booking.stop}</span>
                  </div>
                  <div className="flex items-center gap-2 text-slate-600">
                    <Users className="w-5 h-5" />
                    <span className="font-medium">Validity: {booking.validity}</span>
                  </div>
                </div>

                {/* Discount Badge */}
                {booking.discount && (
                  <div className="inline-flex items-center gap-2 bg-emerald-100 text-emerald-700 px-3 py-1 rounded-lg mb-5">
                    <span className="text-sm font-bold">{booking.discount}</span>
                  </div>
                )}

                {/* Promotion Message */}
                {booking.promotion && (
                  <div className="bg-emerald-50 border-2 border-emerald-200 rounded-2xl p-4 mb-5">
                    <div className="flex items-start gap-3">
                      <div className="w-8 h-8 bg-emerald-500 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                        <FileText className="w-4 h-4 text-white" />
                      </div>
                      <div>
                        <p className="font-bold text-emerald-900 text-sm mb-1">
                          You have a promotion on this booking
                        </p>
                        <p className="text-sm text-emerald-700">
                          {booking.promotion}
                        </p>
                      </div>
                    </div>
                  </div>
                )}

                {/* Action Buttons */}
                <div className="grid grid-cols-2 gap-3 mb-4">
                  <button className="px-6 py-3 bg-white border-2 border-slate-200 rounded-2xl font-semibold text-slate-700 hover:border-slate-300 hover:bg-slate-50 transition-all flex items-center justify-center gap-2">
                    <FileText className="w-4 h-4" />
                    Modify
                  </button>
                  <button className="px-6 py-3 bg-white border-2 border-slate-200 rounded-2xl font-semibold text-slate-700 hover:border-slate-300 hover:bg-slate-50 transition-all">
                    ✕ Cancel
                  </button>
                </div>

                {/* Get Details Button */}
                <button className="w-full px-6 py-3.5 bg-white border border-slate-200 rounded-2xl font-semibold text-slate-700 hover:bg-slate-50 transition-all flex items-center justify-between">
                  <span>Get details</span>
                  <ChevronRight className="w-5 h-5" />
                </button>
              </div>
            </motion.div>
          ))}

          {currentBookings.length === 0 && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="text-center py-16"
            >
              <div className="w-24 h-24 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Bus className="w-12 h-12 text-slate-400" />
              </div>
              <h3 className="text-xl font-bold text-slate-900 mb-2">
                No {activeTab} passes
              </h3>
              <p className="text-slate-600 mb-6">
                You don't have any {activeTab} bus passes yet
              </p>
            </motion.div>
          )}
        </div>
      </div>

      {/* Bottom Navigation (Mobile-style) */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-slate-200 shadow-2xl md:hidden">
        <div className="grid grid-cols-5 px-2 py-3">
          {[
            { icon: "🏠", label: "Home", path: "/" },
            { icon: "🔍", label: "Search", path: "/pass-registration" },
            { icon: "📋", label: "Passes", path: "/view-pass", active: true },
            { icon: "❤️", label: "Favorites", path: "/complaint" },
            { icon: "👤", label: "Profile", path: "/student-login" },
          ].map((item) => (
            <a
              key={item.label}
              href={item.path}
              className={`flex flex-col items-center gap-1 ${
                item.active ? "text-emerald-600" : "text-slate-600"
              }`}
            >
              <span className="text-2xl">{item.icon}</span>
              <span className="text-xs font-medium">{item.label}</span>
            </a>
          ))}
        </div>
      </div>
    </div>
  );
}
