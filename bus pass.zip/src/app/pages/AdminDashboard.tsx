import { Navbar } from "../components/Navbar";
import { useState } from "react";
import {
  Users,
  FileText,
  MessageSquare,
  Bus,
  TrendingUp,
  Activity,
  Calendar,
  MapPin,
} from "lucide-react";
import { mockData } from "../utils/api";

type TabType = "overview" | "students" | "passes" | "complaints" | "routes";

export function AdminDashboard() {
  const [activeTab, setActiveTab] = useState<TabType>("overview");

  const stats = [
    {
      label: "Total Students",
      value: mockData.students.length,
      icon: Users,
      color: "orange",
      change: "+12%",
    },
    {
      label: "Active Passes",
      value: mockData.passes.filter((p) => p.status === "Active").length,
      icon: FileText,
      color: "amber",
      change: "+8%",
    },
    {
      label: "Complaints",
      value: mockData.complaints.length,
      icon: MessageSquare,
      color: "yellow",
      change: "-5%",
    },
    {
      label: "Total Buses",
      value: mockData.buses.length,
      icon: Bus,
      color: "red",
      change: "+2",
    },
  ];

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString("en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
    });
  };

  const getStudentName = (id: number) => {
    const student = mockData.students.find((s) => s.student_id === id);
    return student ? student.name : "Unknown";
  };

  const getRouteName = (id: number) => {
    const route = mockData.routes.find((r) => r.route_id === id);
    return route ? route.route_name : "Unknown";
  };

  const getStopName = (id: number) => {
    const stop = mockData.stops.find((s) => s.stop_id === id);
    return stop ? stop.stop_name : "Unknown";
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-black">
      <Navbar />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Page Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-white mb-2">
            Admin Dashboard
          </h1>
          <p className="text-slate-300">
            Manage students, passes, and complaints
          </p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {stats.map((stat, index) => {
            const Icon = stat.icon;
            const gradientClasses = {
              orange: "bg-gradient-to-br from-orange-400 to-orange-600 shadow-orange-500/50",
              amber: "bg-gradient-to-br from-amber-400 to-amber-600 shadow-amber-500/50",
              yellow: "bg-gradient-to-br from-yellow-400 to-yellow-600 shadow-yellow-500/50",
              red: "bg-gradient-to-br from-rose-400 to-rose-600 shadow-rose-500/50",
            };

            return (
              <div key={index} className="bg-gradient-to-br from-slate-800/90 via-slate-900/90 to-black/90 backdrop-blur-xl rounded-2xl shadow-2xl p-6 border border-slate-700/50 hover:border-slate-600/50 transition-all">
                <div className="flex items-center justify-between mb-4">
                  <div
                    className={`w-14 h-14 ${
                      gradientClasses[stat.color as keyof typeof gradientClasses]
                    } rounded-2xl flex items-center justify-center shadow-2xl`}
                  >
                    <Icon className="w-7 h-7 text-white" />
                  </div>
                  <span className="text-sm font-medium text-emerald-400 flex items-center gap-1">
                    <TrendingUp className="w-4 h-4" />
                    {stat.change}
                  </span>
                </div>
                <p className="text-sm text-slate-400 mb-1">{stat.label}</p>
                <p className="text-3xl font-bold text-white">{stat.value}</p>
              </div>
            );
          })}
        </div>

        {/* Tabs */}
        <div className="bg-gradient-to-br from-slate-800/90 via-slate-900/90 to-black/90 backdrop-blur-xl rounded-2xl shadow-2xl mb-6 border border-slate-700/50">
          <div className="flex overflow-x-auto border-b border-slate-700/50">
            {[
              { id: "overview", label: "Overview", icon: Activity },
              { id: "students", label: "Students", icon: Users },
              { id: "passes", label: "Passes", icon: FileText },
              { id: "complaints", label: "Complaints", icon: MessageSquare },
              { id: "routes", label: "Routes & Buses", icon: Bus },
            ].map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as TabType)}
                  className={`flex items-center gap-2 px-6 py-4 font-semibold transition-colors whitespace-nowrap ${
                    activeTab === tab.id
                      ? "text-indigo-400 border-b-2 border-indigo-400"
                      : "text-slate-400 hover:text-white"
                  }`}
                >
                  <Icon className="w-5 h-5" />
                  {tab.label}
                </button>
              );
            })}
          </div>
        </div>

        {/* Tab Content */}
        <div className="bg-gradient-to-br from-slate-800/90 via-slate-900/90 to-black/90 backdrop-blur-xl rounded-2xl shadow-2xl overflow-hidden border border-slate-700/50">
          {/* Overview Tab */}
          {activeTab === "overview" && (
            <div className="p-6">
              <h2 className="text-xl font-bold text-white mb-6">
                System Overview
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h3 className="font-semibold text-white mb-3">
                    Recent Activities
                  </h3>
                  <div className="space-y-3">
                    <div className="flex items-center gap-3 p-3 bg-slate-800/50 rounded-lg border border-slate-700/30">
                      <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                      <span className="text-sm text-slate-300">
                        New pass registered for John Doe
                      </span>
                    </div>
                    <div className="flex items-center gap-3 p-3 bg-slate-800/50 rounded-lg border border-slate-700/30">
                      <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                      <span className="text-sm text-slate-300">
                        Student Jane Smith registered
                      </span>
                    </div>
                    <div className="flex items-center gap-3 p-3 bg-slate-800/50 rounded-lg border border-slate-700/30">
                      <div className="w-2 h-2 bg-orange-500 rounded-full"></div>
                      <span className="text-sm text-slate-300">
                        New complaint submitted
                      </span>
                    </div>
                  </div>
                </div>
                <div>
                  <h3 className="font-semibold text-white mb-3">
                    Quick Stats
                  </h3>
                  <div className="space-y-3">
                    <div className="flex justify-between items-center p-3 bg-slate-800/50 rounded-lg border border-slate-700/30">
                      <span className="text-sm text-slate-300">
                        Routes Available
                      </span>
                      <span className="font-semibold text-white">
                        {mockData.routes.length}
                      </span>
                    </div>
                    <div className="flex justify-between items-center p-3 bg-slate-800/50 rounded-lg border border-slate-700/30">
                      <span className="text-sm text-slate-300">Total Stops</span>
                      <span className="font-semibold text-white">
                        {mockData.stops.length}
                      </span>
                    </div>
                    <div className="flex justify-between items-center p-3 bg-slate-800/50 rounded-lg border border-slate-700/30">
                      <span className="text-sm text-slate-300">
                        Pass Utilization
                      </span>
                      <span className="font-semibold text-emerald-400">87%</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Students Tab */}
          {activeTab === "students" && (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-slate-800/50 border-b border-slate-700/50">
                  <tr>
                    <th className="px-6 py-4 text-left text-xs font-semibold text-slate-300 uppercase">
                      ID
                    </th>
                    <th className="px-6 py-4 text-left text-xs font-semibold text-slate-300 uppercase">
                      Name
                    </th>
                    <th className="px-6 py-4 text-left text-xs font-semibold text-slate-300 uppercase">
                      Department
                    </th>
                    <th className="px-6 py-4 text-left text-xs font-semibold text-slate-300 uppercase">
                      Year
                    </th>
                    <th className="px-6 py-4 text-left text-xs font-semibold text-slate-300 uppercase">
                      Mobile
                    </th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-700/30">
                  {mockData.students.map((student) => (
                    <tr
                      key={student.student_id}
                      className="hover:bg-slate-800/30 transition-colors"
                    >
                      <td className="px-6 py-4 text-sm text-slate-300">
                        {student.student_id}
                      </td>
                      <td className="px-6 py-4 text-sm font-medium text-white">
                        {student.name}
                      </td>
                      <td className="px-6 py-4 text-sm text-slate-400">
                        {student.department}
                      </td>
                      <td className="px-6 py-4 text-sm text-slate-400">
                        {student.year}
                      </td>
                      <td className="px-6 py-4 text-sm text-slate-400">
                        {student.mobile}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {/* Passes Tab */}
          {activeTab === "passes" && (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-slate-800/50 border-b border-slate-700/50">
                  <tr>
                    <th className="px-6 py-4 text-left text-xs font-semibold text-slate-300 uppercase">
                      Pass ID
                    </th>
                    <th className="px-6 py-4 text-left text-xs font-semibold text-slate-300 uppercase">
                      Student
                    </th>
                    <th className="px-6 py-4 text-left text-xs font-semibold text-slate-300 uppercase">
                      Route
                    </th>
                    <th className="px-6 py-4 text-left text-xs font-semibold text-slate-300 uppercase">
                      Stop
                    </th>
                    <th className="px-6 py-4 text-left text-xs font-semibold text-slate-300 uppercase">
                      Validity
                    </th>
                    <th className="px-6 py-4 text-left text-xs font-semibold text-slate-300 uppercase">
                      Status
                    </th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-700/30">
                  {mockData.passes.map((pass) => (
                    <tr
                      key={pass.pass_id}
                      className="hover:bg-slate-800/30 transition-colors"
                    >
                      <td className="px-6 py-4 text-sm text-slate-300">
                        #{pass.pass_id}
                      </td>
                      <td className="px-6 py-4 text-sm font-medium text-white">
                        {getStudentName(pass.student_id)}
                      </td>
                      <td className="px-6 py-4 text-sm text-slate-400">
                        {getRouteName(pass.route_id)}
                      </td>
                      <td className="px-6 py-4 text-sm text-slate-400">
                        {getStopName(pass.stop_id)}
                      </td>
                      <td className="px-6 py-4 text-sm text-slate-400">
                        {formatDate(pass.valid_from)} - {formatDate(pass.valid_to)}
                      </td>
                      <td className="px-6 py-4">
                        <span
                          className={`inline-flex px-3 py-1 text-xs font-semibold rounded-full ${
                            pass.status === "Active"
                              ? "bg-emerald-500/20 text-emerald-400 border border-emerald-500/30"
                              : "bg-slate-700/50 text-slate-400 border border-slate-600/30"
                          }`}
                        >
                          {pass.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {/* Complaints Tab */}
          {activeTab === "complaints" && (
            <div className="divide-y divide-slate-700/30">
              {mockData.complaints.map((complaint) => (
                <div key={complaint.complaint_id} className="p-6 hover:bg-slate-800/30 transition-colors">
                  <div className="flex justify-between items-start mb-3">
                    <div>
                      <h4 className="font-semibold text-white">
                        Complaint #{complaint.complaint_id}
                      </h4>
                      <p className="text-sm text-slate-400">
                        Student: {getStudentName(complaint.student_id)}
                      </p>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-slate-400">
                      <Calendar className="w-4 h-4" />
                      {formatDate(complaint.date)}
                    </div>
                  </div>
                  <p className="text-slate-300 mb-3">{complaint.description}</p>
                  <div className="flex gap-2">
                    <button className="px-4 py-2 bg-emerald-600 text-white rounded-lg text-sm hover:bg-emerald-700 transition-colors shadow-lg">
                      Mark as Resolved
                    </button>
                    <button className="px-4 py-2 border border-slate-600 text-slate-300 rounded-lg text-sm hover:bg-slate-800/50 transition-colors">
                      Contact Student
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Routes & Buses Tab */}
          {activeTab === "routes" && (
            <div className="p-6">
              <div className="mb-8">
                <h3 className="text-lg font-semibold text-white mb-4">
                  Bus Routes
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {mockData.routes.map((route) => {
                    const routeStops = mockData.stops.filter(
                      (s) => s.route_id === route.route_id
                    );
                    return (
                      <div
                        key={route.route_id}
                        className="border border-slate-700/50 bg-slate-800/30 rounded-xl p-4 hover:border-slate-600/50 transition-all"
                      >
                        <div className="flex items-center gap-2 mb-3">
                          <MapPin className="w-5 h-5 text-indigo-400" />
                          <h4 className="font-semibold text-white">
                            {route.route_name}
                          </h4>
                        </div>
                        <p className="text-sm text-slate-400 mb-2">
                          {routeStops.length} stops
                        </p>
                        <div className="flex flex-wrap gap-1">
                          {routeStops.map((stop) => (
                            <span
                              key={stop.stop_id}
                              className="px-2 py-1 bg-slate-700/50 text-slate-300 rounded text-xs border border-slate-600/30"
                            >
                              {stop.stop_name}
                            </span>
                          ))}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              <div>
                <h3 className="text-lg font-semibold text-white mb-4">
                  Bus Fleet
                </h3>
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="bg-slate-800/50 border-b border-slate-700/50">
                      <tr>
                        <th className="px-6 py-4 text-left text-xs font-semibold text-slate-300 uppercase">
                          Bus ID
                        </th>
                        <th className="px-6 py-4 text-left text-xs font-semibold text-slate-300 uppercase">
                          Bus Number
                        </th>
                        <th className="px-6 py-4 text-left text-xs font-semibold text-slate-300 uppercase">
                          Capacity
                        </th>
                        <th className="px-6 py-4 text-left text-xs font-semibold text-slate-300 uppercase">
                          Status
                        </th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-700/30">
                      {mockData.buses.map((bus) => (
                        <tr
                          key={bus.bus_id}
                          className="hover:bg-slate-800/30 transition-colors"
                        >
                          <td className="px-6 py-4 text-sm text-slate-300">
                            {bus.bus_id}
                          </td>
                          <td className="px-6 py-4 text-sm font-medium text-white">
                            {bus.bus_number}
                          </td>
                          <td className="px-6 py-4 text-sm text-slate-400">
                            {bus.capacity} seats
                          </td>
                          <td className="px-6 py-4">
                            <span className="inline-flex px-3 py-1 text-xs font-semibold rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                              Active
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}