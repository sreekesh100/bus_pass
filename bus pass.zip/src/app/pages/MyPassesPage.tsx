import { Header } from "../components/Header";
import { Footer } from "../components/Footer";
import { Calendar, Download, RefreshCw, Trash2, CheckCircle, Clock, XCircle, QrCode } from "lucide-react";
import { useState } from "react";

export function MyPassesPage() {
  const [activeTab, setActiveTab] = useState<"active" | "expired" | "all">("active");

  const myPasses = [
    {
      id: "MP001",
      name: "Monthly Pass",
      type: "regular",
      purchaseDate: "2026-03-01",
      validFrom: "2026-03-01",
      validUntil: "2026-03-31",
      status: "active",
      price: 80,
      icon: "📆",
      qrCode: "QR123456789",
      usageCount: 42,
    },
    {
      id: "MP002",
      name: "Weekend Pass",
      type: "special",
      purchaseDate: "2026-03-05",
      validFrom: "2026-03-08",
      validUntil: "2026-03-09",
      status: "upcoming",
      price: 12,
      icon: "🎉",
      qrCode: "QR987654321",
      usageCount: 0,
    },
    {
      id: "MP003",
      name: "Weekly Pass",
      type: "regular",
      purchaseDate: "2026-02-10",
      validFrom: "2026-02-10",
      validUntil: "2026-02-17",
      status: "expired",
      price: 25,
      icon: "📅",
      qrCode: "QR456789123",
      usageCount: 28,
    },
    {
      id: "MP004",
      name: "Student Pass",
      type: "discounted",
      purchaseDate: "2026-02-28",
      validFrom: "2026-03-01",
      validUntil: "2026-03-31",
      status: "active",
      price: 40,
      icon: "🎓",
      qrCode: "QR741852963",
      usageCount: 38,
    },
  ];

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "active":
        return (
          <span className="inline-flex items-center gap-1 px-3 py-1 bg-green-100 text-green-700 rounded-full text-sm font-medium">
            <CheckCircle className="w-4 h-4" />
            Active
          </span>
        );
      case "upcoming":
        return (
          <span className="inline-flex items-center gap-1 px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-sm font-medium">
            <Clock className="w-4 h-4" />
            Upcoming
          </span>
        );
      case "expired":
        return (
          <span className="inline-flex items-center gap-1 px-3 py-1 bg-gray-100 text-gray-700 rounded-full text-sm font-medium">
            <XCircle className="w-4 h-4" />
            Expired
          </span>
        );
      default:
        return null;
    }
  };

  const filteredPasses = myPasses.filter((pass) => {
    if (activeTab === "active") return pass.status === "active" || pass.status === "upcoming";
    if (activeTab === "expired") return pass.status === "expired";
    return true;
  });

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
      year: "numeric",
    });
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <Header />

      {/* Page Header */}
      <section className="bg-gradient-to-r from-red-600 to-red-700 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="text-4xl font-bold mb-4">My Passes</h1>
          <p className="text-xl text-red-50">
            Manage and view all your bus passes in one place
          </p>
        </div>
      </section>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 mb-1">Active Passes</p>
                <p className="text-3xl font-bold text-gray-900">
                  {myPasses.filter((p) => p.status === "active").length}
                </p>
              </div>
              <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                <CheckCircle className="w-6 h-6 text-green-600" />
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 mb-1">Total Trips</p>
                <p className="text-3xl font-bold text-gray-900">
                  {myPasses.reduce((sum, pass) => sum + pass.usageCount, 0)}
                </p>
              </div>
              <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                <RefreshCw className="w-6 h-6 text-blue-600" />
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 mb-1">Money Saved</p>
                <p className="text-3xl font-bold text-gray-900">$127</p>
              </div>
              <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center">
                <span className="text-2xl">💰</span>
              </div>
            </div>
          </div>
        </div>

        {/* Tabs */}
        <div className="bg-white rounded-lg shadow-md mb-6">
          <div className="flex border-b border-gray-200">
            <button
              onClick={() => setActiveTab("active")}
              className={`flex-1 px-6 py-4 font-semibold transition-colors ${
                activeTab === "active"
                  ? "text-red-600 border-b-2 border-red-600"
                  : "text-gray-600 hover:text-red-600"
              }`}
            >
              Active Passes ({myPasses.filter((p) => p.status === "active" || p.status === "upcoming").length})
            </button>
            <button
              onClick={() => setActiveTab("expired")}
              className={`flex-1 px-6 py-4 font-semibold transition-colors ${
                activeTab === "expired"
                  ? "text-red-600 border-b-2 border-red-600"
                  : "text-gray-600 hover:text-red-600"
              }`}
            >
              Expired ({myPasses.filter((p) => p.status === "expired").length})
            </button>
            <button
              onClick={() => setActiveTab("all")}
              className={`flex-1 px-6 py-4 font-semibold transition-colors ${
                activeTab === "all"
                  ? "text-red-600 border-b-2 border-red-600"
                  : "text-gray-600 hover:text-red-600"
              }`}
            >
              All Passes ({myPasses.length})
            </button>
          </div>
        </div>

        {/* Passes List */}
        {filteredPasses.length === 0 ? (
          <div className="bg-white rounded-lg shadow-md p-12 text-center">
            <div className="text-6xl mb-4">🎫</div>
            <h3 className="text-2xl font-bold text-gray-900 mb-2">
              No passes found
            </h3>
            <p className="text-gray-600 mb-6">
              You don't have any {activeTab !== "all" ? activeTab : ""} passes yet.
            </p>
            <a
              href="/passes"
              className="inline-block px-6 py-3 bg-red-600 text-white rounded-lg font-semibold hover:bg-red-700 transition-colors"
            >
              Browse Passes
            </a>
          </div>
        ) : (
          <div className="space-y-6">
            {filteredPasses.map((pass) => (
              <div
                key={pass.id}
                className="bg-white rounded-xl shadow-md hover:shadow-lg transition-shadow border border-gray-100 overflow-hidden"
              >
                <div className="p-6">
                  <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
                    {/* Pass Info */}
                    <div className="flex items-start gap-4 flex-1">
                      <div className="text-5xl">{pass.icon}</div>
                      <div className="flex-1">
                        <div className="flex items-start justify-between gap-4 mb-2">
                          <div>
                            <h3 className="text-xl font-bold text-gray-900">
                              {pass.name}
                            </h3>
                            <p className="text-sm text-gray-600">
                              Pass ID: {pass.id}
                            </p>
                          </div>
                          {getStatusBadge(pass.status)}
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-4">
                          <div className="flex items-center gap-2 text-sm text-gray-600">
                            <Calendar className="w-4 h-4" />
                            <span>
                              Valid: {formatDate(pass.validFrom)} -{" "}
                              {formatDate(pass.validUntil)}
                            </span>
                          </div>
                          <div className="flex items-center gap-2 text-sm text-gray-600">
                            <RefreshCw className="w-4 h-4" />
                            <span>Used {pass.usageCount} times</span>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* QR Code Placeholder */}
                    {pass.status === "active" && (
                      <div className="flex flex-col items-center gap-2">
                        <div className="w-32 h-32 bg-gray-100 rounded-lg flex items-center justify-center border-2 border-gray-300">
                          <QrCode className="w-20 h-20 text-gray-400" />
                        </div>
                        <p className="text-xs text-gray-600">Scan to use</p>
                      </div>
                    )}
                  </div>

                  {/* Actions */}
                  <div className="flex flex-wrap gap-3 mt-6 pt-6 border-t border-gray-200">
                    {pass.status === "active" && (
                      <>
                        <button className="flex items-center gap-2 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors">
                          <Download className="w-4 h-4" />
                          Download Pass
                        </button>
                        <button className="flex items-center gap-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors text-gray-700">
                          <QrCode className="w-4 h-4" />
                          Show QR Code
                        </button>
                      </>
                    )}
                    {pass.status === "expired" && (
                      <button className="flex items-center gap-2 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors">
                        <RefreshCw className="w-4 h-4" />
                        Renew Pass
                      </button>
                    )}
                    <button className="flex items-center gap-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors text-gray-700">
                      <Calendar className="w-4 h-4" />
                      View Details
                    </button>
                    {pass.status === "upcoming" && (
                      <button className="flex items-center gap-2 px-4 py-2 border border-red-300 text-red-600 rounded-lg hover:bg-red-50 transition-colors ml-auto">
                        <Trash2 className="w-4 h-4" />
                        Cancel
                      </button>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <Footer />
    </div>
  );
}
