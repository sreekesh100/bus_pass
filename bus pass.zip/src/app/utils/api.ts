// Mock API Base URL - Replace with your actual Supabase/Backend URL
const API_BASE_URL = "https://your-supabase-project.supabase.co/rest/v1";
const API_KEY = "your-supabase-anon-key";

// Helper function for API calls
const apiCall = async (endpoint: string, options: RequestInit = {}) => {
  try {
    const response = await fetch(`${API_BASE_URL}${endpoint}`, {
      ...options,
      headers: {
        "Content-Type": "application/json",
        "apikey": API_KEY,
        "Authorization": `Bearer ${API_KEY}`,
        ...options.headers,
      },
    });

    if (!response.ok) {
      throw new Error(`API Error: ${response.statusText}`);
    }

    return await response.json();
  } catch (error) {
    console.error("API Call Error:", error);
    throw error;
  }
};

// Student APIs
export const studentAPI = {
  getAll: () => apiCall("/students?select=*"),
  getById: (id: number) => apiCall(`/students?student_id=eq.${id}`),
  create: (data: any) =>
    apiCall("/students", {
      method: "POST",
      body: JSON.stringify(data),
    }),
  update: (id: number, data: any) =>
    apiCall(`/students?student_id=eq.${id}`, {
      method: "PATCH",
      body: JSON.stringify(data),
    }),
  delete: (id: number) =>
    apiCall(`/students?student_id=eq.${id}`, {
      method: "DELETE",
    }),
};

// Bus APIs
export const busAPI = {
  getAll: () => apiCall("/buses?select=*"),
  getById: (id: number) => apiCall(`/buses?bus_id=eq.${id}`),
  create: (data: any) =>
    apiCall("/buses", {
      method: "POST",
      body: JSON.stringify(data),
    }),
};

// Route APIs
export const routeAPI = {
  getAll: () => apiCall("/routes?select=*"),
  getById: (id: number) => apiCall(`/routes?route_id=eq.${id}`),
};

// Stop APIs
export const stopAPI = {
  getAll: () => apiCall("/stops?select=*"),
  getByRouteId: (routeId: number) => apiCall(`/stops?route_id=eq.${routeId}`),
};

// Pass APIs
export const passAPI = {
  getAll: () => apiCall("/passes?select=*"),
  getByStudentId: (studentId: number) =>
    apiCall(`/passes?student_id=eq.${studentId}`),
  create: (data: any) =>
    apiCall("/passes", {
      method: "POST",
      body: JSON.stringify(data),
    }),
  update: (id: number, data: any) =>
    apiCall(`/passes?pass_id=eq.${id}`, {
      method: "PATCH",
      body: JSON.stringify(data),
    }),
};

// Complaint APIs
export const complaintAPI = {
  getAll: () => apiCall("/complaints?select=*"),
  create: (data: any) =>
    apiCall("/complaints", {
      method: "POST",
      body: JSON.stringify(data),
    }),
};

// Mock data for development (use when backend is not available)
export const mockData = {
  // Authentication data
  users: {
    admin: {
      email: "sreekeshs@gmail.com",
      password: "sreekesh",
      role: "admin",
      name: "Admin User",
    },
    student: {
      email: "sreekeshs@gmail.com",
      password: "sreekesh",
      role: "student",
      student_id: 1,
    },
  },
  students: [
    {
      student_id: 1,
      name: "Sreekesh S",
      email: "sreekeshs@gmail.com",
      department: "Computer Science",
      year: "3rd Year",
      mobile: "9876543210",
    },
    {
      student_id: 2,
      name: "Jane Smith",
      department: "Electronics",
      year: "2nd Year",
      mobile: "9876543211",
    },
    {
      student_id: 3,
      name: "Mike Johnson",
      department: "Mechanical",
      year: "4th Year",
      mobile: "9876543212",
    },
  ],
  buses: [
    { bus_id: 1, bus_number: "KA-01-AB-1234", capacity: 50 },
    { bus_id: 2, bus_number: "KA-01-AB-5678", capacity: 40 },
    { bus_id: 3, bus_number: "KA-01-AB-9012", capacity: 45 },
  ],
  routes: [
    { route_id: 1, route_name: "Route A - North Campus" },
    { route_id: 2, route_name: "Route B - South Campus" },
    { route_id: 3, route_name: "Route C - East Campus" },
  ],
  stops: [
    { stop_id: 1, stop_name: "Main Gate", route_id: 1 },
    { stop_id: 2, stop_name: "Library", route_id: 1 },
    { stop_id: 3, stop_name: "Hostel Block A", route_id: 1 },
    { stop_id: 4, stop_name: "City Center", route_id: 2 },
    { stop_id: 5, stop_name: "Railway Station", route_id: 2 },
    { stop_id: 6, stop_name: "Market Square", route_id: 3 },
  ],
  passes: [
    {
      pass_id: 1,
      student_id: 1,
      route_id: 1,
      stop_id: 1,
      valid_from: "2026-03-01",
      valid_to: "2026-06-30",
      status: "Active",
      fee_amount: 2500,
      fee_due_date: "2026-03-15",
      fee_paid: false,
    },
    {
      pass_id: 2,
      student_id: 2,
      route_id: 2,
      stop_id: 4,
      valid_from: "2026-03-01",
      valid_to: "2026-06-30",
      status: "Active",
      fee_amount: 2500,
      fee_due_date: "2026-03-15",
      fee_paid: true,
    },
  ],
  dayTickets: [
    {
      ticket_id: 1,
      student_id: 1,
      route_id: 1,
      stop_id: 1,
      travel_date: "2026-03-10",
      booking_date: "2026-03-07",
      status: "Active",
      amount: 50,
      qr_code: "TICKET-1-1-20260310",
    },
  ],
  complaints: [
    {
      complaint_id: 1,
      student_id: 1,
      description: "Bus was late by 30 minutes",
      date: "2026-03-05",
    },
    {
      complaint_id: 2,
      student_id: 2,
      description: "AC not working properly",
      date: "2026-03-04",
    },
  ],
};

// Authentication helper functions
export const authAPI = {
  login: (email: string, password: string, role: 'student' | 'admin') => {
    // Mock authentication
    const user = mockData.users[role];
    
    if (user.email === email && user.password === password) {
      // Store user data in localStorage
      const userData = {
        ...user,
        ...(role === 'student' ? { studentData: mockData.students.find(s => s.student_id === user.student_id) } : {})
      };
      localStorage.setItem('currentUser', JSON.stringify(userData));
      return { success: true, user: userData };
    }
    
    return { success: false, error: 'Invalid credentials' };
  },
  
  logout: () => {
    localStorage.removeItem('currentUser');
  },
  
  getCurrentUser: () => {
    const userStr = localStorage.getItem('currentUser');
    return userStr ? JSON.parse(userStr) : null;
  },
  
  isAuthenticated: () => {
    return localStorage.getItem('currentUser') !== null;
  }
};