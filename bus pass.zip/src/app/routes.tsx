import { createBrowserRouter } from "react-router";
import { HomePage } from "./pages/HomePage";
import { StudentRegistrationPage } from "./pages/StudentRegistrationPage";
import { BusPassRegistrationPage } from "./pages/BusPassRegistrationPage";
import { ViewBusPassPage } from "./pages/ViewBusPassPage";
import { ComplaintPage } from "./pages/ComplaintPage";
import { AdminDashboard } from "./pages/AdminDashboard";
import { StudentLoginPage } from "./pages/StudentLoginPage";
import { AdminLoginPage } from "./pages/AdminLoginPage";
import { UnifiedLoginPage } from "./pages/UnifiedLoginPage";
import { StudentDashboard } from "./pages/StudentDashboard";
import { BookDayTicketPage } from "./pages/BookDayTicketPage";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: HomePage,
  },
  {
    path: "/student-registration",
    Component: StudentRegistrationPage,
  },
  {
    path: "/login",
    Component: UnifiedLoginPage,
  },
  {
    path: "/student-login",
    Component: StudentLoginPage,
  },
  {
    path: "/admin-login",
    Component: AdminLoginPage,
  },
  {
    path: "/student-dashboard",
    Component: StudentDashboard,
  },
  {
    path: "/book-day-ticket",
    Component: BookDayTicketPage,
  },
  {
    path: "/pass-registration",
    Component: BusPassRegistrationPage,
  },
  {
    path: "/view-pass",
    Component: ViewBusPassPage,
  },
  {
    path: "/complaint",
    Component: ComplaintPage,
  },
  {
    path: "/admin",
    Component: AdminDashboard,
  },
  {
    path: "/admin-dashboard",
    Component: AdminDashboard,
  },
]);