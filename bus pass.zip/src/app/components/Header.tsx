import { Link, useLocation } from "react-router";
import { Bus, User, Menu, Ticket } from "lucide-react";
import { useState } from "react";

export function Header() {
  const location = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const isActive = (path: string) => location.pathname === path;

  return (
    <header className="bg-white shadow-sm sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-2">
            <div className="bg-red-600 p-2 rounded-lg">
              <Bus className="w-6 h-6 text-white" />
            </div>
            <span className="text-xl font-bold text-gray-900">BusPass</span>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-8">
            <Link
              to="/"
              className={`${
                isActive("/")
                  ? "text-red-600"
                  : "text-gray-700 hover:text-red-600"
              } transition-colors`}
            >
              Home
            </Link>
            <Link
              to="/passes"
              className={`${
                isActive("/passes")
                  ? "text-red-600"
                  : "text-gray-700 hover:text-red-600"
              } transition-colors`}
            >
              Browse Passes
            </Link>
            <Link
              to="/my-passes"
              className={`${
                isActive("/my-passes")
                  ? "text-red-600"
                  : "text-gray-700 hover:text-red-600"
              } transition-colors`}
            >
              My Passes
            </Link>
          </nav>

          {/* User Actions */}
          <div className="hidden md:flex items-center gap-4">
            <button className="flex items-center gap-2 px-4 py-2 text-gray-700 hover:text-red-600 transition-colors">
              <User className="w-5 h-5" />
              <span>Login</span>
            </button>
            <button className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors">
              Sign Up
            </button>
          </div>

          {/* Mobile Menu Button */}
          <button
            className="md:hidden p-2"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            <Menu className="w-6 h-6 text-gray-700" />
          </button>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="md:hidden py-4 border-t border-gray-200">
            <nav className="flex flex-col gap-4">
              <Link
                to="/"
                className={`${
                  isActive("/") ? "text-red-600" : "text-gray-700"
                } px-4 py-2`}
                onClick={() => setMobileMenuOpen(false)}
              >
                Home
              </Link>
              <Link
                to="/passes"
                className={`${
                  isActive("/passes") ? "text-red-600" : "text-gray-700"
                } px-4 py-2`}
                onClick={() => setMobileMenuOpen(false)}
              >
                Browse Passes
              </Link>
              <Link
                to="/my-passes"
                className={`${
                  isActive("/my-passes") ? "text-red-600" : "text-gray-700"
                } px-4 py-2`}
                onClick={() => setMobileMenuOpen(false)}
              >
                My Passes
              </Link>
              <div className="px-4 py-2 flex flex-col gap-2">
                <button className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700">
                  Login
                </button>
                <button className="px-4 py-2 bg-red-600 text-white rounded-lg">
                  Sign Up
                </button>
              </div>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
}
