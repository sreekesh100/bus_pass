import { Bus, Mail, Phone, MapPin, Facebook, Twitter, Instagram, Linkedin } from "lucide-react";
import { Link } from "react-router";

export function Footer() {
  return (
    <footer className="bg-gray-900 text-gray-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* About */}
          <div>
            <div className="flex items-center gap-2 mb-4">
              <div className="bg-red-600 p-2 rounded-lg">
                <Bus className="w-5 h-5 text-white" />
              </div>
              <span className="text-xl font-bold text-white">BusPass</span>
            </div>
            <p className="text-sm text-gray-400 mb-4">
              Your trusted partner for convenient and affordable bus pass management. Travel smart, travel easy.
            </p>
            <div className="flex gap-4">
              <a href="#" className="hover:text-red-500 transition-colors">
                <Facebook className="w-5 h-5" />
              </a>
              <a href="#" className="hover:text-red-500 transition-colors">
                <Twitter className="w-5 h-5" />
              </a>
              <a href="#" className="hover:text-red-500 transition-colors">
                <Instagram className="w-5 h-5" />
              </a>
              <a href="#" className="hover:text-red-500 transition-colors">
                <Linkedin className="w-5 h-5" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-white font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link to="/" className="hover:text-red-500 transition-colors">
                  Home
                </Link>
              </li>
              <li>
                <Link to="/passes" className="hover:text-red-500 transition-colors">
                  Browse Passes
                </Link>
              </li>
              <li>
                <Link to="/my-passes" className="hover:text-red-500 transition-colors">
                  My Passes
                </Link>
              </li>
              <li>
                <a href="#" className="hover:text-red-500 transition-colors">
                  FAQ
                </a>
              </li>
            </ul>
          </div>

          {/* Pass Types */}
          <div>
            <h3 className="text-white font-semibold mb-4">Pass Types</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <a href="#" className="hover:text-red-500 transition-colors">
                  Daily Pass
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-red-500 transition-colors">
                  Weekly Pass
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-red-500 transition-colors">
                  Monthly Pass
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-red-500 transition-colors">
                  Student Pass
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-red-500 transition-colors">
                  Senior Citizen Pass
                </a>
              </li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="text-white font-semibold mb-4">Contact Us</h3>
            <ul className="space-y-3 text-sm">
              <li className="flex items-start gap-2">
                <MapPin className="w-4 h-4 mt-0.5 flex-shrink-0" />
                <span>123 Transit Street, Metro City, MC 12345</span>
              </li>
              <li className="flex items-center gap-2">
                <Phone className="w-4 h-4 flex-shrink-0" />
                <span>+1 (555) 123-4567</span>
              </li>
              <li className="flex items-center gap-2">
                <Mail className="w-4 h-4 flex-shrink-0" />
                <span>support@buspass.com</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-8 pt-8 text-sm text-center text-gray-400">
          <p>&copy; 2026 BusPass. All rights reserved. | Privacy Policy | Terms of Service</p>
        </div>
      </div>
    </footer>
  );
}
