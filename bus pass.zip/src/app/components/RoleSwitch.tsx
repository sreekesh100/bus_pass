import { motion } from 'motion/react';
import { User, Shield } from 'lucide-react';

interface RoleSwitchProps {
  activeRole: 'student' | 'admin';
  onRoleChange: (role: 'student' | 'admin') => void;
}

export function RoleSwitch({ activeRole, onRoleChange }: RoleSwitchProps) {
  return (
    <div className="relative inline-flex bg-white rounded-2xl p-1 shadow-lg border border-slate-200">
      {/* Animated Background Slider */}
      <motion.div
        className="absolute top-1 bottom-1 rounded-xl bg-gradient-to-r from-indigo-500 to-indigo-600 shadow-md"
        initial={false}
        animate={{
          left: activeRole === 'student' ? '4px' : '50%',
          right: activeRole === 'student' ? '50%' : '4px',
        }}
        transition={{
          type: 'spring',
          stiffness: 300,
          damping: 30,
        }}
      />

      {/* Student Option */}
      <button
        onClick={() => onRoleChange('student')}
        className={`relative z-10 flex items-center gap-2 px-6 py-3 rounded-xl font-semibold transition-colors ${
          activeRole === 'student'
            ? 'text-white'
            : 'text-slate-600 hover:text-slate-900'
        }`}
      >
        <User className="w-5 h-5" />
        <span>Student</span>
      </button>

      {/* Admin Option */}
      <button
        onClick={() => onRoleChange('admin')}
        className={`relative z-10 flex items-center gap-2 px-6 py-3 rounded-xl font-semibold transition-colors ${
          activeRole === 'admin'
            ? 'text-white'
            : 'text-slate-600 hover:text-slate-900'
        }`}
      >
        <Shield className="w-5 h-5" />
        <span>Admin</span>
      </button>
    </div>
  );
}
