import { useEffect, useRef } from 'react';
import { motion } from 'motion/react';

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  type: 'student' | 'bus' | 'dot';
  color: string;
}

export function AnimatedCampusScene() {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Set canvas size
    const resizeCanvas = () => {
      canvas.width = canvas.offsetWidth;
      canvas.height = canvas.offsetHeight;
    };
    resizeCanvas();
    window.addEventListener('resize', resizeCanvas);

    // Particles array
    const particles: Particle[] = [];

    // Create students (walking figures)
    for (let i = 0; i < 8; i++) {
      particles.push({
        x: Math.random() * canvas.width,
        y: canvas.height * 0.6 + Math.random() * 100,
        vx: 0.5 + Math.random() * 1,
        vy: (Math.random() - 0.5) * 0.2,
        size: 12 + Math.random() * 8,
        type: 'student',
        color: ['#6366f1', '#8b5cf6', '#ec4899', '#10b981'][Math.floor(Math.random() * 4)],
      });
    }

    // Create buses
    for (let i = 0; i < 2; i++) {
      particles.push({
        x: Math.random() * canvas.width,
        y: canvas.height * 0.4 + i * 60,
        vx: 1.5 + Math.random() * 0.5,
        vy: 0,
        size: 40,
        type: 'bus',
        color: '#fbbf24',
      });
    }

    // Create floating dots (ambient particles)
    for (let i = 0; i < 30; i++) {
      particles.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        vx: (Math.random() - 0.5) * 0.5,
        vy: (Math.random() - 0.5) * 0.5,
        size: 2 + Math.random() * 3,
        type: 'dot',
        color: 'rgba(255, 255, 255, 0.3)',
      });
    }

    // Draw student (stick figure with backpack)
    const drawStudent = (x: number, y: number, size: number, color: string) => {
      ctx.fillStyle = color;
      ctx.strokeStyle = color;
      ctx.lineWidth = 2;

      // Head
      ctx.beginPath();
      ctx.arc(x, y - size * 0.7, size * 0.3, 0, Math.PI * 2);
      ctx.fill();

      // Body
      ctx.beginPath();
      ctx.moveTo(x, y - size * 0.4);
      ctx.lineTo(x, y + size * 0.2);
      ctx.stroke();

      // Legs
      ctx.beginPath();
      ctx.moveTo(x, y + size * 0.2);
      ctx.lineTo(x - size * 0.3, y + size * 0.6);
      ctx.moveTo(x, y + size * 0.2);
      ctx.lineTo(x + size * 0.3, y + size * 0.6);
      ctx.stroke();

      // Arms
      ctx.beginPath();
      ctx.moveTo(x, y - size * 0.2);
      ctx.lineTo(x - size * 0.4, y + size * 0.1);
      ctx.moveTo(x, y - size * 0.2);
      ctx.lineTo(x + size * 0.4, y + size * 0.1);
      ctx.stroke();

      // Backpack (small rectangle)
      ctx.fillStyle = color;
      ctx.fillRect(x - size * 0.2, y - size * 0.3, size * 0.4, size * 0.3);
    };

    // Draw bus
    const drawBus = (x: number, y: number, size: number, color: string) => {
      // Bus body
      ctx.fillStyle = color;
      ctx.fillRect(x - size * 0.5, y - size * 0.3, size, size * 0.6);

      // Windows
      ctx.fillStyle = '#1e293b';
      ctx.fillRect(x - size * 0.35, y - size * 0.2, size * 0.25, size * 0.25);
      ctx.fillRect(x + size * 0.1, y - size * 0.2, size * 0.25, size * 0.25);

      // Wheels
      ctx.fillStyle = '#0f172a';
      ctx.beginPath();
      ctx.arc(x - size * 0.25, y + size * 0.3, size * 0.15, 0, Math.PI * 2);
      ctx.fill();
      ctx.beginPath();
      ctx.arc(x + size * 0.25, y + size * 0.3, size * 0.15, 0, Math.PI * 2);
      ctx.fill();

      // Bus number/sign
      ctx.fillStyle = '#fff';
      ctx.font = `${size * 0.2}px sans-serif`;
      ctx.textAlign = 'center';
      ctx.fillText('🚌', x, y);
    };

    // Animation loop
    let animationFrameId: number;

    const animate = () => {
      // Clear canvas with fade effect
      ctx.fillStyle = 'rgba(109, 40, 217, 0.1)';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // Update and draw particles
      particles.forEach((particle) => {
        // Update position
        particle.x += particle.vx;
        particle.y += particle.vy;

        // Wrap around screen
        if (particle.x > canvas.width + 50) {
          particle.x = -50;
        }
        if (particle.y > canvas.height + 50) {
          particle.y = -50;
        }
        if (particle.y < -50) {
          particle.y = canvas.height + 50;
        }

        // Draw based on type
        if (particle.type === 'student') {
          drawStudent(particle.x, particle.y, particle.size, particle.color);
        } else if (particle.type === 'bus') {
          drawBus(particle.x, particle.y, particle.size, particle.color);
        } else if (particle.type === 'dot') {
          ctx.fillStyle = particle.color;
          ctx.beginPath();
          ctx.arc(particle.x, particle.y, particle.size, 0, Math.PI * 2);
          ctx.fill();
        }
      });

      animationFrameId = requestAnimationFrame(animate);
    };

    animate();

    // Cleanup
    return () => {
      window.removeEventListener('resize', resizeCanvas);
      cancelAnimationFrame(animationFrameId);
    };
  }, []);

  return (
    <motion.canvas
      ref={canvasRef}
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 1 }}
      className="absolute inset-0 w-full h-full"
      style={{ mixBlendMode: 'screen' }}
    />
  );
}
