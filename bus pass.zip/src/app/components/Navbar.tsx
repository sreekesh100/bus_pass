import { Link, useLocation, useNavigate } from "react-router";
import { Home, Menu, X, User, FileText, MessageSquare, Search, Bus, LogOut } from "lucide-react";
import { useState } from "react";
import { authAPI } from "../utils/api";

export function Navbar() {
  const location = useLocation();
  const navigate = useNavigate();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const currentUser = authAPI.getCurrentUser();

  const isActive = (path: string) => location.pathname === path;

  const handleLogout = () => {
    authAPI.logout();
    navigate("/");
  };

  const navLinks = currentUser
    ? [
        { path: "/", label: "Home", icon: Home },
        {
          path: currentUser.role === "admin" ? "/admin-dashboard" : "/student-dashboard",
          label: "Dashboard",
          icon: FileText,
        },
        { path: "/view-pass", label: "View Pass", icon: Search },
        { path: "/complaint", label: "Complaint", icon: MessageSquare },
      ]
    : [
        { path: "/", label: "Home", icon: Home },
        { path: "/login", label: "Login", icon: User },
        { path: "/pass-registration", label: "Pass Registration", icon: FileText },
        { path: "/view-pass", label: "View Pass", icon: Search },
        { path: "/complaint", label: "Complaint", icon: MessageSquare },
      ];

  return (
    <nav className="bg-white/95 backdrop-blur-lg text-slate-800 shadow-sm sticky top-0 z-50 border-b border-slate-200/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-20">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-3 group">
            {/* Creative Logo - Bus Ticket Style */}
            <div className="relative">
              {/* Ticket Shape */}
              <div className="relative w-14 h-14">
                {/* Main ticket body */}
                <div className="absolute inset-0 bg-gradient-to-br from-indigo-600 via-indigo-500 to-purple-600 rounded-lg transform group-hover:scale-105 transition-transform duration-300 shadow-lg">
                  {/* Perforated edge effect */}
                  <div className="absolute -left-1 top-1/2 -translate-y-1/2 w-2 h-2 bg-white rounded-full"></div>
                  <div className="absolute -right-1 top-1/2 -translate-y-1/2 w-2 h-2 bg-white rounded-full"></div>
                  
                  {/* Top notches */}
                  <div className="absolute left-3 -top-0.5 w-1.5 h-1.5 bg-white rounded-full"></div>
                  <div className="absolute right-3 -top-0.5 w-1.5 h-1.5 bg-white rounded-full"></div>
                  
                  {/* Bus Icon in center */}
                  <div className="absolute inset-0 flex items-center justify-center">
                    <Bus className="w-7 h-7 text-white" strokeWidth={2.5} />
                  </div>
                  
                  {/* Accent stripe */}
                  <div className="absolute bottom-2 left-2 right-2 h-0.5 bg-amber-400 rounded-full"></div>
                </div>
                
                {/* Floating sparkle */}
                <div className="absolute -top-1 -right-1 w-3 h-3 bg-amber-400 rounded-full animate-ping opacity-75"></div>
                <div className="absolute -top-1 -right-1 w-3 h-3 bg-amber-400 rounded-full"></div>
              </div>
            </div>
            
            <div className="flex flex-col">
              <span className="text-xl font-bold text-slate-800 tracking-tight leading-tight">
                College Bus Pass
              </span>
              <span className="text-xs text-indigo-600 font-semibold -mt-0.5 tracking-wide">
                SMART CAMPUS TRAVEL
              </span>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-2">
            {navLinks.map((link) => {
              const Icon = link.icon;
              const active = isActive(link.path);
              return (
                <Link
                  key={link.path}
                  to={link.path}
                  className={`flex items-center gap-2 px-4 py-2.5 rounded-xl transition-all duration-200 ${
                    active
                      ? "bg-indigo-600 text-white shadow-md shadow-indigo-200"
                      : "text-slate-600 hover:bg-slate-100 hover:text-slate-900"
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  <span className="text-sm font-medium">{link.label}</span>
                </Link>
              );
            })}
            {currentUser && (
              <button
                className="flex items-center gap-2 px-4 py-2.5 rounded-xl transition-all duration-200 bg-indigo-600 text-white shadow-md shadow-indigo-200"
                onClick={handleLogout}
              >
                <LogOut className="w-4 h-4" />
                <span className="text-sm font-medium">Logout</span>
              </button>
            )}
          </div>

          {/* Mobile Menu Button */}
          <button
            className="md:hidden p-2.5 hover:bg-slate-100 rounded-xl transition-colors"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            {mobileMenuOpen ? (
              <X className="w-6 h-6 text-slate-700" />
            ) : (
              <Menu className="w-6 h-6 text-slate-700" />
            )}
          </button>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="md:hidden py-4 border-t border-slate-200">
            {navLinks.map((link) => {
              const Icon = link.icon;
              const active = isActive(link.path);
              return (
                <Link
                  key={link.path}
                  to={link.path}
                  className={`flex items-center gap-3 px-4 py-3 rounded-xl transition-all mb-2 ${
                    active
                      ? "bg-indigo-600 text-white shadow-md"
                      : "text-slate-600 hover:bg-slate-100"
                  }`}
                  onClick={() => setMobileMenuOpen(false)}
                >
                  <Icon className="w-5 h-5" />
                  <span className="font-medium">{link.label}</span>
                </Link>
              );
            })}
            {currentUser && (
              <button
                className="flex items-center gap-3 px-4 py-3 rounded-xl transition-all mb-2 bg-indigo-600 text-white shadow-md"
                onClick={handleLogout}
              >
                <LogOut className="w-5 h-5" />
                <span className="font-medium">Logout</span>
              </button>
            )}
          </div>
        )}
      </div>
    </nav>
  );
}